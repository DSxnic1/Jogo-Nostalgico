extends BaseGame
# ─────────────────────────────────────
#  Tetris.gd
# ─────────────────────────────────────

const COLS := 10
const ROWS := 20
const BLOCK := 28

const COLORS := [
	Color(0,0,0,0),          # 0 empty
	Color(0.00,1.00,0.67),   # 1 I  cyan-green
	Color(1.00,0.85,0.30),   # 2 O  yellow
	Color(0.75,0.37,1.00),   # 3 T  purple
	Color(1.00,0.47,0.20),   # 4 L  orange
	Color(0.00,0.81,1.00),   # 5 J  blue
	Color(1.00,0.20,0.40),   # 6 S  red
	Color(0.00,1.00,0.50),   # 7 Z  green
]

const SHAPES := [
	[],                                        # 0
	[[0,0],[1,0],[2,0],[3,0]],                 # I
	[[0,0],[1,0],[0,1],[1,1]],                 # O
	[[1,0],[0,1],[1,1],[2,1]],                 # T
	[[2,0],[0,1],[1,1],[2,1]],                 # L
	[[0,0],[0,1],[1,1],[2,1]],                 # J
	[[1,0],[2,0],[0,1],[1,1]],                 # S
	[[0,0],[1,0],[1,1],[2,1]],                 # Z
]

var board: Array = []
var piece_type: int = 0
var piece_cells: Array = []
var next_type: int = 0
var piece_x: int = 0
var piece_y: int = 0
var score: int = 0
var lines: int = 0
var level: int = 1
var game_over: bool = false
var drop_timer: float = 0.0
var _canvas: Control
var _next_canvas: Control
var _score_lbl: Label
var _lines_lbl: Label
var _level_lbl: Label

func _game_init() -> void:
	game_title = "TETRIS"
	accent_color = ArcadeTheme.C_GREEN

func _game_ready() -> void:

	var hbox := HBoxContainer.new()
	hbox.add_theme_constant_override("separation", 20)
	_content.add_child(hbox)

	# Game canvas
	_canvas = Control.new()
	_canvas.custom_minimum_size = Vector2(COLS * BLOCK, ROWS * BLOCK)
	_canvas.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	hbox.add_child(_canvas)
	_canvas.draw.connect(_draw_board)

	# Side panel
	var side := VBoxContainer.new()
	side.add_theme_constant_override("separation", 12)
	side.custom_minimum_size.x = 140
	hbox.add_child(side)

	var hud := make_hud_row([
		{"label":"SCORE","id":"score","color":ArcadeTheme.C_GREEN,"value":"0"},
	])
	side.add_child(hud)
	_score_lbl = hud.get_node("score")

	var hud2 := make_hud_row([
		{"label":"LINHAS","id":"lines","color":ArcadeTheme.C_BLUE,"value":"0"},
	])
	side.add_child(hud2)
	_lines_lbl = hud2.get_node("lines")

	var hud3 := make_hud_row([
		{"label":"NÍVEL","id":"level","color":ArcadeTheme.C_YELLOW,"value":"1"},
	])
	side.add_child(hud3)
	_level_lbl = hud3.get_node("level")

	var next_lbl := Label.new()
	next_lbl.text = "PRÓXIMA"
	next_lbl.add_theme_font_size_override("font_size", 10)
	next_lbl.add_theme_color_override("font_color", ArcadeTheme.C_DIM)
	side.add_child(next_lbl)

	_next_canvas = Control.new()
	_next_canvas.custom_minimum_size = Vector2(5*BLOCK, 4*BLOCK)
	_next_canvas.draw.connect(_draw_next)
	side.add_child(_next_canvas)

	var new_btn := make_gbtn("NOVO JOGO")
	new_btn.pressed.connect(start_game)
	side.add_child(new_btn)

	var hint := Label.new()
	hint.text = "← → ↑ GIRAR\n↓ DESCER  SPC DROP"
	hint.add_theme_font_size_override("font_size", 10)
	hint.add_theme_color_override("font_color", ArcadeTheme.C_DIM)
	side.add_child(hint)

	start_game()

func start_game() -> void:
	board = []
	for _r in range(ROWS):
		board.append(Array())
		for _c in range(COLS):
			board[-1].append(0)
	score = 0; lines = 0; level = 1; game_over = false
	_score_lbl.text = "0"; _lines_lbl.text = "0"; _level_lbl.text = "1"
	set_status("")
	next_type = randi_range(1, 7)
	_spawn_piece()

func _spawn_piece() -> void:
	piece_type = next_type
	next_type = randi_range(1, 7)
	piece_x = COLS // 2 - 2
	piece_y = 0
	piece_cells = SHAPES[piece_type].duplicate(true)
	if _collides(piece_cells, piece_x, piece_y):
		game_over = true
		set_status("💀 GAME OVER — SCORE: " + str(score), ArcadeTheme.C_RED)
	_canvas.queue_redraw()
	_next_canvas.queue_redraw()

func _process(delta: float) -> void:
	if game_over: return
	drop_timer += delta
	var interval := maxf(0.08, 0.5 - level * 0.04)
	if drop_timer >= interval:
		drop_timer = 0.0
		_move_down()

func _input(event: InputEvent) -> void:
	if game_over or not visible: return
	if event is InputEventKey and event.pressed:
		match event.keycode:
			KEY_LEFT:  _try_move(-1, 0)
			KEY_RIGHT: _try_move(1, 0)
			KEY_DOWN:  _move_down(); score += 1; _score_lbl.text = str(score)
			KEY_UP:    _rotate()
			KEY_SPACE: _hard_drop()

func _try_move(dx: int, dy: int) -> void:
	if not _collides(piece_cells, piece_x + dx, piece_y + dy):
		piece_x += dx; piece_y += dy
		_canvas.queue_redraw()

func _move_down() -> void:
	if _collides(piece_cells, piece_x, piece_y + 1):
		_lock()
	else:
		piece_y += 1
		_canvas.queue_redraw()

func _hard_drop() -> void:
	while not _collides(piece_cells, piece_x, piece_y + 1):
		piece_y += 1; score += 2
	_score_lbl.text = str(score)
	_lock()

func _rotate() -> void:
	var rotated := []
	for cell in piece_cells:
		rotated.append([cell[1], -cell[0]])
	# Normalize
	var min_x := INF; var min_y := INF
	for c in rotated:
		min_x = minf(min_x, c[0]); min_y = minf(min_y, c[1])
	for i in rotated.size():
		rotated[i] = [rotated[i][0] - min_x, rotated[i][1] - min_y]
	if not _collides(rotated, piece_x, piece_y):
		piece_cells = rotated
		_canvas.queue_redraw()

func _collides(cells: Array, ox: int, oy: int) -> bool:
	for cell in cells:
		var cx: int = ox + (cell[0] as int); var cy: int = oy + (cell[1] as int)
		if cx < 0 or cx >= COLS or cy >= ROWS: return true
		if cy >= 0 and board[cy][cx] != 0: return true
	return false

func _lock() -> void:
	for cell in piece_cells:
		var cx: int = piece_x + (cell[0] as int); var cy: int = piece_y + (cell[1] as int)
		if cy >= 0: board[cy][cx] = piece_type
	# Clear lines
	var cleared := 0
	var r := ROWS - 1
	while r >= 0:
		if board[r].all(func(v): return v != 0):
			board.remove_at(r)
			board.insert(0, Array())
			for _c in range(COLS): board[0].append(0)
			cleared += 1
		else:
			r -= 1
	lines += cleared
	score += [0, 100, 300, 500, 800][cleared] * level
	level = lines // 10 + 1
	_score_lbl.text = str(score)
	_lines_lbl.text = str(lines)
	_level_lbl.text = str(level)
	_spawn_piece()

func _draw_board() -> void:
	var cv := _canvas
	# Background
	cv.draw_rect(Rect2(0, 0, COLS*BLOCK, ROWS*BLOCK), ArcadeTheme.C_BG)
	# Grid
	for r in range(ROWS):
		for c in range(COLS):
			cv.draw_rect(Rect2(c*BLOCK+1, r*BLOCK+1, BLOCK-2, BLOCK-2), Color(0.08,0.08,0.15))
	# Board pieces
	for r in range(ROWS):
		for c in range(COLS):
			if board[r][c] != 0:
				_draw_block(cv, c, r, COLORS[board[r][c]])
	# Ghost
	var gy := piece_y
	while not _collides(piece_cells, piece_x, gy + 1): gy += 1
	for cell in piece_cells:
		var cx: int = piece_x + (cell[0] as int); var cy: int = gy + (cell[1] as int)
		if cy >= 0:
			var ghost_col: Color = COLORS[piece_type]
			ghost_col.a = 0.25
			cv.draw_rect(Rect2(cx*BLOCK+2, cy*BLOCK+2, BLOCK-4, BLOCK-4), ghost_col)
	# Active piece
	for cell in piece_cells:
		var cx: int = piece_x + (cell[0] as int); var cy: int = piece_y + (cell[1] as int)
		if cy >= 0: _draw_block(cv, cx, cy, COLORS[piece_type])
	# Border
	cv.draw_rect(Rect2(0, 0, COLS*BLOCK, ROWS*BLOCK), ArcadeTheme.C_BORDER, false, 1.5)

func _draw_next() -> void:
	var cv := _next_canvas
	cv.draw_rect(Rect2(0, 0, cv.size.x, cv.size.y), ArcadeTheme.C_PANEL2)
	for cell in SHAPES[next_type]:
		_draw_block_at(cv, (cell[0]+1)*BLOCK, (cell[1]+1)*BLOCK, COLORS[next_type])

func _draw_block(cv: Control, cx: int, cy: int, color: Color) -> void:
	_draw_block_at(cv, cx * BLOCK, cy * BLOCK, color)

func _draw_block_at(cv: Control, px: int, py: int, color: Color) -> void:
	cv.draw_rect(Rect2(px+1, py+1, BLOCK-2, BLOCK-2), color)
	cv.draw_rect(Rect2(px+2, py+2, BLOCK-4, 3), Color(1,1,1,0.22))
	cv.draw_rect(Rect2(px+1, py+BLOCK-4, BLOCK-2, 3), Color(0,0,0,0.22))
