extends BaseGame
# ─────────────────────────────────────
#  WordSearch.gd
# ─────────────────────────────────────

const SIZE := 14
const CELL := 34.0
const WORDS := ["GATO","LEAO","PEIXE","URSO","LOBO","TIGRE","COBRA","AGUIA","ORCA","BURRO"]
const DIRS := [Vector2i(0,1),Vector2i(1,0),Vector2i(1,1),Vector2i(-1,1),
               Vector2i(0,-1),Vector2i(-1,0),Vector2i(-1,-1),Vector2i(1,-1)]

var grid: Array = []
var placed: Array = []   # {word, cells: [Vector2i]}
var found: Array = []    # found word strings
var sel_start: Vector2i = Vector2i(-1,-1)
var sel_cells: Array = []
var found_cells: Array = []   # flat list of Vector2i
var _canvas: Control
var _word_labels: Array = []
var _found_lbl: Label; var _rem_lbl: Label

func _game_init() -> void:
	game_title = "CAÇA PALAVRAS"
	accent_color = ArcadeTheme.C_GREEN

func _game_ready() -> void:

	var vbox := VBoxContainer.new(); vbox.add_theme_constant_override("separation",10)
	_content.add_child(vbox)
	var hud := make_hud_row([
		{"label":"ENCONTRADAS","id":"found","color":ArcadeTheme.C_GREEN,"value":"0"},
		{"label":"RESTANTES","id":"rem","color":ArcadeTheme.C_YELLOW,"value":str(WORDS.size())},
	])
	vbox.add_child(hud)
	_found_lbl=hud.get_node("found"); _rem_lbl=hud.get_node("rem")

	var main_hbox := HBoxContainer.new(); main_hbox.add_theme_constant_override("separation",14)
	vbox.add_child(main_hbox)

	_canvas = Control.new()
	_canvas.custom_minimum_size=Vector2(SIZE*CELL,SIZE*CELL)
	_canvas.size_flags_horizontal=Control.SIZE_SHRINK_BEGIN
	_canvas.draw.connect(_draw_grid); _canvas.gui_input.connect(_on_input)
	_canvas.mouse_filter=Control.MOUSE_FILTER_STOP
	main_hbox.add_child(_canvas)

	var word_vbox := VBoxContainer.new(); word_vbox.add_theme_constant_override("separation",4)
	var wl := Label.new(); wl.text="PALAVRAS"
	wl.add_theme_font_size_override("font_size",10); wl.add_theme_color_override("font_color",ArcadeTheme.C_DIM)
	word_vbox.add_child(wl)
	_word_labels=[]
	for w in WORDS:
		var lbl := Label.new(); lbl.text=w; lbl.name=w
		lbl.add_theme_font_size_override("font_size",13); lbl.add_theme_color_override("font_color",ArcadeTheme.C_DIM)
		word_vbox.add_child(lbl); _word_labels.append(lbl)
	main_hbox.add_child(word_vbox)

	var btn := make_gbtn("NOVO JOGO",ArcadeTheme.C_GREEN); btn.pressed.connect(start_game); vbox.add_child(btn)
	var hint := Label.new(); hint.text="Clique na 1ª letra, depois na última"
	hint.add_theme_font_size_override("font_size",11); hint.add_theme_color_override("font_color",ArcadeTheme.C_DIM)
	vbox.add_child(hint); start_game()

func start_game() -> void:
	grid=Array(); placed=[]; found=[]; sel_start=Vector2i(-1,-1); sel_cells=[]; found_cells=[]
	for _r in range(SIZE): grid.append([]); for _c in range(SIZE): grid[-1].append("")
	_place_words(); _fill_grid()
	_found_lbl.text="0"; _rem_lbl.text=str(WORDS.size()); set_status("")
	for lbl in _word_labels: lbl.add_theme_color_override("font_color",ArcadeTheme.C_DIM)
	_canvas.queue_redraw()

func _place_words() -> void:
	var shuffled:=WORDS.duplicate(); shuffled.shuffle()
	for w in shuffled:
		for _try in range(300):
			var d: Vector2i = DIRS[randi()%DIRS.size()]
			var r:=randi()%SIZE; var c:=randi()%SIZE
			var er:=r+d.y*(w.length()-1); var ec:=c+d.x*(w.length()-1)
			if er<0 or er>=SIZE or ec<0 or ec>=SIZE: continue
			var ok:=true; var cells_tmp:=[]
			for i in w.length():
				var nr:=r+d.y*i; var nc:=c+d.x*i
				if grid[nr][nc]!="" and grid[nr][nc]!=w[i]: ok=false; break
				cells_tmp.append(Vector2i(nc,nr))
			if ok:
				for i in w.length(): grid[cells_tmp[i].y][cells_tmp[i].x]=w[i]
				placed.append({"word":w,"cells":cells_tmp}); break

func _fill_grid() -> void:
	var alpha:="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
	for r in range(SIZE):
		for c in range(SIZE):
			if grid[r][c]=="": grid[r][c]=alpha[randi()%alpha.length()]

func _on_input(event:InputEvent) -> void:
	if not (event is InputEventMouseButton and event.pressed and event.button_index==1): return
	var c:=int(event.position.x/CELL); var r:=int(event.position.y/CELL)
	if r<0 or r>=SIZE or c<0 or c>=SIZE: return
	var pos:=Vector2i(c,r)
	if sel_start==Vector2i(-1,-1):
		sel_start=pos; sel_cells=[pos]; _canvas.queue_redraw(); return
	# Build line from sel_start to pos
	var dr:=sign(r-sel_start.y); var dc:=sign(c-sel_start.x)
	var length:=max(abs(r-sel_start.y),abs(c-sel_start.x))
	var line:=[]
	for i in range(length+1): line.append(Vector2i(sel_start.x+dc*i,sel_start.y+dr*i))
	var word:=""; for p in line: word+=grid[p.y][p.x]
	var rev:=word.reverse()  # GDScript doesn't have string reverse easily
	var rword:=""; for i in range(word.length()-1,-1,-1): rword+=word[i]
	var match_found:=""
	for p_data in placed:
		if p_data["word"]==word or p_data["word"]==rword:
			match_found=p_data["word"]; break
	if match_found!="" and not match_found in found:
		found.append(match_found)
		for p2 in placed:
			if p2["word"]==match_found: for cell in p2["cells"]: found_cells.append(cell)
		for lbl in _word_labels:
			if lbl.text==match_found: lbl.add_theme_color_override("font_color",ArcadeTheme.C_GREEN)
		_found_lbl.text=str(found.size()); _rem_lbl.text=str(WORDS.size()-found.size())
		if found.size()==placed.size(): set_status("🏆 TODAS ENCONTRADAS!", ArcadeTheme.C_GREEN)
		sel_cells=line
	else: sel_cells=line
	sel_start=Vector2i(-1,-1)
	_canvas.queue_redraw()
	await get_tree().create_timer(0.5).timeout
	sel_cells=[]; _canvas.queue_redraw()

func _draw_grid() -> void:
	var cv:=_canvas
	cv.draw_rect(Rect2(0,0,SIZE*CELL,SIZE*CELL),ArcadeTheme.C_PANEL2)
	for r in range(SIZE):
		for c in range(SIZE):
			var rx:=c*CELL; var ry:=r*CELL
			var pos:=Vector2i(c,r)
			var bg:=ArcadeTheme.C_PANEL2
			if pos in found_cells: bg=Color(0,0.18,0.10)
			elif pos in sel_cells: bg=Color(0.15,0.12,0)
			cv.draw_rect(Rect2(rx+1,ry+1,CELL-2,CELL-2),bg)
			var letter_col:=ArcadeTheme.C_DIM
			if pos in found_cells: letter_col=ArcadeTheme.C_GREEN
			elif pos in sel_cells: letter_col=ArcadeTheme.C_YELLOW
			cv.draw_string(ThemeDB.fallback_font,Vector2(rx+CELL/2-7,ry+CELL-8),
				grid[r][c],HORIZONTAL_ALIGNMENT_LEFT,-1,int(CELL-8),letter_col)
	cv.draw_rect(Rect2(0,0,SIZE*CELL,SIZE*CELL),ArcadeTheme.C_BORDER,false,1.0)
