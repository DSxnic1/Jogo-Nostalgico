extends BaseGame
# ─────────────────────────────────────
#  Solitaire.gd  —  Klondike
# ─────────────────────────────────────

const SUITS := ["♠","♥","♦","♣"]
const RANKS := ["A","2","3","4","5","6","7","8","9","10","J","Q","K"]
const RED_SUITS := ["♥","♦"]
const CW := 72.0; const CH := 100.0; const VOFFSET := 22.0; const GAP := 8.0

var stock: Array = []
var waste: Array = []
var foundations: Array = [[],[],[],[]]
var tableau: Array = []
var score_val: int = 0; var moves_val: int = 0
var sel_pile: Variant = null   # null | "waste" | "fnd:N" | int (tableau index)
var sel_idx: int = -1
var _canvas: Control
var _score_lbl: Label; var _moves_lbl: Label

func _rv(r:String) -> int: return RANKS.find(r)
func _is_red(s:String) -> bool: return s in RED_SUITS

func _game_init() -> void:
	game_title = "PACIÊNCIA"
	accent_color = ArcadeTheme.C_RED

func _game_ready() -> void:

	var vbox := VBoxContainer.new(); vbox.add_theme_constant_override("separation",10)
	_content.add_child(vbox)
	var hud := make_hud_row([
		{"label":"SCORE","id":"score","color":ArcadeTheme.C_RED,"value":"0"},
		{"label":"MOVIMENTOS","id":"moves","color":ArcadeTheme.C_BLUE,"value":"0"},
	])
	vbox.add_child(hud)
	_score_lbl=hud.get_node("score"); _moves_lbl=hud.get_node("moves")

	var scroll := ScrollContainer.new(); scroll.size_flags_vertical=Control.SIZE_EXPAND_FILL
	_canvas = Control.new()
	var w:=(CW+GAP)*7-GAP+GAP*2; var h:=CH+(VOFFSET*13+CH)+GAP*3
	_canvas.custom_minimum_size=Vector2(w,h)
	_canvas.size_flags_horizontal=Control.SIZE_SHRINK_BEGIN
	_canvas.draw.connect(_draw_board); _canvas.gui_input.connect(_on_input)
	_canvas.mouse_filter=Control.MOUSE_FILTER_STOP
	scroll.add_child(_canvas); vbox.add_child(scroll)

	var btn := make_gbtn("NOVO JOGO",ArcadeTheme.C_RED); btn.pressed.connect(start_game); vbox.add_child(btn)
	var hint := Label.new(); hint.text="Clique para selecionar • Clique no destino para mover  |  Clique no baralho para virar carta"
	hint.add_theme_font_size_override("font_size",10); hint.add_theme_color_override("font_color",ArcadeTheme.C_DIM)
	vbox.add_child(hint); start_game()

func start_game() -> void:
	var deck:=[]
	for s in SUITS: for r in RANKS: deck.append({"r":r,"s":s,"up":false})
	deck.shuffle()
	tableau=Array(); for _i in 7: tableau.append([])
	for i in range(7):
		for j in range(i,7):
			var cd:=deck.pop_back(); if j==i: cd["up"]=true; tableau[j].append(cd)
	stock=deck.map(func(c): return {"r":c["r"],"s":c["s"],"up":false})
	waste=[]; foundations=[[],[],[],[]]; score_val=0; moves_val=0
	_score_lbl.text="0"; _moves_lbl.text="0"; set_status(""); sel_pile=null; sel_idx=-1
	_canvas.queue_redraw()

func _on_input(event:InputEvent) -> void:
	if not (event is InputEventMouseButton and event.pressed and event.button_index==1): return
	var p:=event.position; _handle_click(p)

func _handle_click(p:Vector2) -> void:
	var ox:=GAP; var oy:=GAP
	# Stock
	if Rect2(ox,oy,CW,CH).has_point(p):
		if stock.size()>0:
			var cd:=stock.pop_back(); cd["up"]=true; waste.append(cd)
		else:
			stock=waste.duplicate(); stock.reverse()
			stock=stock.map(func(c): return {"r":c["r"],"s":c["s"],"up":false}); waste=[]
		sel_pile=null; sel_idx=-1; _canvas.queue_redraw(); return
	# Waste
	if waste.size()>0 and Rect2(ox+CW+GAP,oy,CW,CH).has_point(p):
		if sel_pile=="waste": sel_pile=null; sel_idx=-1
		else: sel_pile="waste"; sel_idx=waste.size()-1
		_canvas.queue_redraw(); return
	# Foundations
	for fi in 4:
		var fx:=ox+(3+fi)*(CW+GAP)
		if Rect2(fx,oy,CW,CH).has_point(p): _try_place_foundation(fi); return
	# Tableau
	for ti in 7:
		var tx:=ox+ti*(CW+GAP); var ty:=oy+CH+GAP
		var pile: Array = tableau[ti]
		if pile.is_empty():
			if Rect2(tx,ty,CW,CH).has_point(p): _try_move_to_tab(ti); return
			continue
		var pile_h:=(pile.size()-1)*VOFFSET+CH
		if not Rect2(tx,ty,CW,pile_h).has_point(p): continue
		var ci:=min(int((p.y-ty)/VOFFSET), pile.size()-1)
		if not pile[ci]["up"]: sel_pile=null; sel_idx=-1; _canvas.queue_redraw(); return
		if sel_pile==ti and sel_idx==ci: sel_pile=null; sel_idx=-1
		elif sel_pile!=null: _try_move_to_tab(ti)
		else: sel_pile=ti; sel_idx=ci
		_canvas.queue_redraw()

func _try_place_foundation(fi:int) -> void:
	var card: Dictionary
	if sel_pile=="waste" and waste.size()>0: card=waste[-1]
	elif sel_pile is int and sel_idx>=0 and sel_idx==tableau[sel_pile].size()-1: card=tableau[sel_pile][-1]
	else: sel_pile=null; sel_idx=-1; _canvas.queue_redraw(); return
	var f: Array = foundations[fi]
	var ok:=(f.is_empty() and card["r"]=="A" and card["s"]==SUITS[fi]) or \
		(not f.is_empty() and f[-1]["s"]==card["s"] and _rv(card["r"])==_rv(f[-1]["r"])+1)
	if ok:
		f.append(card)
		if sel_pile=="waste": waste.pop_back()
		else: tableau[sel_pile].pop_back(); _flip_top(sel_pile)
		score_val+=15; moves_val+=1; _score_lbl.text=str(score_val); _moves_lbl.text=str(moves_val)
		if foundations.all(func(ff): return ff.size()==13): set_status("🏆 VOCÊ VENCEU!", ArcadeTheme.C_GREEN)
	sel_pile=null; sel_idx=-1; _canvas.queue_redraw()

func _try_move_to_tab(ti:int) -> void:
	if sel_pile==null: return
	var cards:=[]
	if sel_pile=="waste" and waste.size()>0: cards=[waste[-1]]
	elif sel_pile is int: cards=tableau[sel_pile].slice(sel_idx)
	if cards.is_empty(): sel_pile=null; sel_idx=-1; _canvas.queue_redraw(); return
	var dest: Array = tableau[ti]; var card: Dictionary = cards[0]
	var ok:=(dest.is_empty() and card["r"]=="K") or \
		(not dest.is_empty() and dest[-1]["up"] and _is_red(card["s"])!=_is_red(dest[-1]["s"]) and _rv(card["r"])==_rv(dest[-1]["r"])-1)
	if ok:
		if sel_pile=="waste": waste.pop_back()
		else: tableau[sel_pile]=tableau[sel_pile].slice(0,sel_idx); _flip_top(sel_pile)
		for c in cards: dest.append(c)
		score_val+=5; moves_val+=1; _score_lbl.text=str(score_val); _moves_lbl.text=str(moves_val)
	sel_pile=null; sel_idx=-1; _canvas.queue_redraw()

func _flip_top(ti:int) -> void:
	if ti is int and tableau[ti].size()>0 and not tableau[ti][-1]["up"]:
		tableau[ti][-1]["up"]=true

func _draw_card(cv:Control, x:float, y:float, card:Dictionary, selected:bool=false) -> void:
	var rect:=Rect2(x,y,CW,CH)
	if not card["up"]:
		cv.draw_rect(rect, Color(0.05,0.05,0.15))
		cv.draw_rect(Rect2(x+3,y+3,CW-6,CH-6), Color(0.08,0.08,0.22))
		cv.draw_rect(rect, ArcadeTheme.C_BORDER, false, 1)
		return
	var bg := Color(0.10,0.10,0.22) if not selected else Color(0.12,0.10,0)
	cv.draw_rect(rect, bg)
	var border := ArcadeTheme.C_YELLOW if selected else ArcadeTheme.C_BORDER
	cv.draw_rect(rect, border, false, 1.5 if selected else 1)
	var col := ArcadeTheme.C_RED if _is_red(card["s"]) else Color(0.75,0.75,0.90)
	cv.draw_string(ThemeDB.fallback_font, Vector2(x+4,y+18), card["r"], HORIZONTAL_ALIGNMENT_LEFT,-1,14,col)
	cv.draw_string(ThemeDB.fallback_font, Vector2(x+CW/2-12,y+CH-8), card["s"], HORIZONTAL_ALIGNMENT_LEFT,-1,22,col)

func _draw_board() -> void:
	var cv:=_canvas; var ox:=GAP; var oy:=GAP
	cv.draw_rect(Rect2(0,0,_canvas.custom_minimum_size.x,_canvas.custom_minimum_size.y), ArcadeTheme.C_BG)
	# Stock
	var sr:=Rect2(ox,oy,CW,CH)
	if stock.size()>0:
		cv.draw_rect(sr, Color(0.05,0.05,0.15)); cv.draw_rect(Rect2(ox+3,oy+3,CW-6,CH-6),Color(0.08,0.08,0.22)); cv.draw_rect(sr,ArcadeTheme.C_BORDER,false,1)
	else:
		cv.draw_rect(sr, ArcadeTheme.C_PANEL2,true); cv.draw_rect(sr,ArcadeTheme.C_DIM,false,1)
		cv.draw_string(ThemeDB.fallback_font,Vector2(ox+20,oy+CH/2+8),"🔄",HORIZONTAL_ALIGNMENT_LEFT,-1,24)
	# Waste
	var wx:=ox+CW+GAP
	if waste.size()>0:
		_draw_card(cv, wx,oy, waste[-1], sel_pile=="waste")
	else:
		cv.draw_rect(Rect2(wx,oy,CW,CH),ArcadeTheme.C_PANEL2); cv.draw_rect(Rect2(wx,oy,CW,CH),ArcadeTheme.C_DIM,false,1)
	# Foundations
	for fi in 4:
		var fx:=ox+(3+fi)*(CW+GAP)
		if foundations[fi].is_empty():
			cv.draw_rect(Rect2(fx,oy,CW,CH),ArcadeTheme.C_PANEL2); cv.draw_rect(Rect2(fx,oy,CW,CH),ArcadeTheme.C_DIM,false,1)
			cv.draw_string(ThemeDB.fallback_font,Vector2(fx+CW/2-10,oy+CH/2+8),SUITS[fi],HORIZONTAL_ALIGNMENT_LEFT,-1,22,ArcadeTheme.C_DIM)
		else: _draw_card(cv, fx,oy, foundations[fi][-1])
	# Tableau
	for ti in 7:
		var tx:=ox+ti*(CW+GAP); var ty:=oy+CH+GAP
		var pile:=tableau[ti]
		if pile.is_empty():
			cv.draw_rect(Rect2(tx,ty,CW,CH),ArcadeTheme.C_PANEL2); cv.draw_rect(Rect2(tx,ty,CW,CH),ArcadeTheme.C_DIM,false,1)
			cv.draw_string(ThemeDB.fallback_font,Vector2(tx+CW/2-8,ty+CH/2+8),"K",HORIZONTAL_ALIGNMENT_LEFT,-1,18,ArcadeTheme.C_DIM)
		for ci in pile.size():
			var cy:=ty+ci*VOFFSET
			var is_sel:=(sel_pile==ti and sel_idx<=ci and pile[ci]["up"])
			_draw_card(cv, tx,cy, pile[ci], is_sel)
