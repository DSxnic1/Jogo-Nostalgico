extends BaseGame
# ─────────────────────────────────────
#  SpaceInvaders.gd
# ─────────────────────────────────────

const W := 560.0; const H := 420.0
const PLAYER_SPD := 260.0
const BULLET_SPD := 380.0
const ENEMY_ROWS := 4; const ENEMY_COLS := 11
const ENEMY_W := 38.0; const ENEMY_H := 28.0
const SHOOT_COOLDOWN := 0.35

var player_x: float = W/2
var player_bullets: Array = []
var enemy_bullets: Array = []
var enemies: Array = []
var e_dir: float = 1.0
var e_speed: float = 40.0
var e_drop: float = 0.0
var score: int = 0; var lives: int = 3; var phase: int = 1
var shoot_timer: float = 0.0
var e_shoot_timer: float = 0.0
var running: bool = false
var _canvas: Control
var _score_lbl: Label; var _lives_lbl: Label; var _phase_lbl: Label

const ENEMY_SYMBOLS := ["👾","🛸","🤖","👽"]

func _game_init() -> void:
	game_title = "SPACE INVADERS"
	accent_color = ArcadeTheme.C_GREEN

func _game_ready() -> void:

	var vbox := VBoxContainer.new(); vbox.add_theme_constant_override("separation",10)
	_content.add_child(vbox)
	var hud := make_hud_row([
		{"label":"SCORE","id":"score","color":ArcadeTheme.C_GREEN,"value":"0"},
		{"label":"VIDAS","id":"lives","color":ArcadeTheme.C_RED,"value":"3"},
		{"label":"FASE","id":"phase","color":ArcadeTheme.C_YELLOW,"value":"1"},
	])
	vbox.add_child(hud)
	_score_lbl = hud.get_node("score"); _lives_lbl = hud.get_node("lives"); _phase_lbl = hud.get_node("phase")
	_canvas = Control.new(); _canvas.custom_minimum_size = Vector2(W,H)
	_canvas.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	_canvas.draw.connect(_draw_game); vbox.add_child(_canvas)
	var btn := make_gbtn("NOVO JOGO", ArcadeTheme.C_GREEN); btn.pressed.connect(start_game)
	vbox.add_child(btn)
	var hint := Label.new(); hint.text = "← →  MOVER  |  ESPAÇO  ATIRAR"
	hint.add_theme_font_size_override("font_size",11); hint.add_theme_color_override("font_color",ArcadeTheme.C_DIM)
	vbox.add_child(hint); start_game()

func start_game() -> void:
	score=0; lives=3; phase=1; e_speed=40.0; running=true
	_score_lbl.text="0"; _lives_lbl.text="3"; _phase_lbl.text="1"; set_status("")
	player_x=W/2; player_bullets=[]; enemy_bullets=[]; _make_enemies()

func _make_enemies() -> void:
	enemies=[]
	for r in range(ENEMY_ROWS):
		for c in range(ENEMY_COLS):
			enemies.append({"x":c*(ENEMY_W+6)+30.0,"y":r*(ENEMY_H+8)+30.0,
				"sym":ENEMY_SYMBOLS[r%ENEMY_SYMBOLS.size()],"alive":true,"pts":(ENEMY_ROWS-r)*10})
	e_dir=1.0; e_drop=0.0

func _process(delta:float) -> void:
	if not running: return
	if Input.is_key_pressed(KEY_LEFT):  player_x = maxf(18, player_x-PLAYER_SPD*delta)
	if Input.is_key_pressed(KEY_RIGHT): player_x = minf(W-18, player_x+PLAYER_SPD*delta)
	shoot_timer += delta
	if Input.is_key_pressed(KEY_SPACE) and shoot_timer >= SHOOT_COOLDOWN:
		shoot_timer=0.0; player_bullets.append(Vector2(player_x, H-55))
	# Move enemies
	var alive := enemies.filter(func(e): return e["alive"])
	if alive.is_empty():
		phase+=1; e_speed=minf(160, e_speed+20); _phase_lbl.text=str(phase); _make_enemies(); return
	var max_x := alive.map(func(e): return e["x"]).max()
	var min_x := alive.map(func(e): return e["x"]).min()
	if max_x > W-30 or min_x < 10: e_dir *= -1; e_drop = 14
	for e in alive:
		e["x"] += e_dir * e_speed * delta
		if e_drop > 0: e["y"] += 1
	if e_drop > 0: e_drop -= 1
	# Enemy shoot
	e_shoot_timer += delta
	if e_shoot_timer >= 0.8 and alive.size() > 0:
		e_shoot_timer=0.0
		var shooter: Dictionary = alive[randi()%alive.size()]
		enemy_bullets.append(Vector2(shooter["x"]+14, shooter["y"]+22))
	# Player bullets
	var new_pb := []
	for b in player_bullets:
		b.y -= BULLET_SPD*delta
		var hit := false
		for e in enemies:
			if e["alive"] and abs(b.x-e["x"]-14)<16 and abs(b.y-e["y"]-14)<14:
				e["alive"]=false; score+=e["pts"]; _score_lbl.text=str(score); hit=true; break
		if not hit and b.y > 0: new_pb.append(b)
	player_bullets = new_pb
	# Enemy bullets
	var new_eb := []
	for b in enemy_bullets:
		b.y += 220*delta
		if abs(b.x-player_x)<18 and b.y > H-55:
			lives-=1; _lives_lbl.text=str(lives)
			if lives<=0: running=false; set_status("💀 GAME OVER!  SCORE:"+str(score),ArcadeTheme.C_RED); return
		elif b.y < H: new_eb.append(b)
	enemy_bullets = new_eb
	if alive.any(func(e): return e["y"] > H-60):
		running=false; set_status("💀 INVASÃO!",ArcadeTheme.C_RED)
	_canvas.queue_redraw()

func _draw_game() -> void:
	var cv := _canvas
	cv.draw_rect(Rect2(0,0,W,H), ArcadeTheme.C_BG)
	# Stars
	for s in [[50,20],[130,80],[210,15],[360,60],[430,100],[30,160],[470,210],[180,310]]:
		cv.draw_rect(Rect2(s[0],s[1],1,1), Color(1,1,1,0.4))
	# Player
	var pts := PackedVector2Array([Vector2(player_x,H-55),Vector2(player_x-18,H-38),Vector2(player_x+18,H-38)])
	cv.draw_colored_polygon(pts, ArcadeTheme.C_GREEN)
	# Bullets
	for b in player_bullets: cv.draw_rect(Rect2(b.x-2,b.y-8,4,10), ArcadeTheme.C_YELLOW)
	for b in enemy_bullets:  cv.draw_rect(Rect2(b.x-2,b.y,4,10), ArcadeTheme.C_RED)
	# Enemies (draw as colored rects with letter)
	for e in enemies:
		if not e["alive"]: continue
		cv.draw_rect(Rect2(e["x"],e["y"],ENEMY_W,ENEMY_H), Color(0.2,0.2,0.4,0.5))
		# Simple enemy shape
		cv.draw_rect(Rect2(e["x"]+4,e["y"]+4,ENEMY_W-8,ENEMY_H-8), ArcadeTheme.C_GREEN)
		cv.draw_rect(Rect2(e["x"]+8,e["y"]+8,ENEMY_W-16,ENEMY_H-16), ArcadeTheme.C_BG)
	cv.draw_rect(Rect2(0,0,W,H), ArcadeTheme.C_BORDER, false, 1.5)
