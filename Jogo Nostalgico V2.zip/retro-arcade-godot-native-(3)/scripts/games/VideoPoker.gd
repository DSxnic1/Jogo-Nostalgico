extends BaseGame
# ─────────────────────────────────────
#  VideoPoker.gd  —  Jacks or Better
# ─────────────────────────────────────

const SUITS := ["♠","♥","♦","♣"]
const RANKS := ["2","3","4","5","6","7","8","9","10","J","Q","K","A"]
const RED_SUITS := ["♥","♦"]

var chips: int = 100
var bet: int = 5
var deck: Array = []
var hand: Array = []
var held: Array = [false,false,false,false,false]
var phase: String = "deal"   # deal, hold, result
var _chips_lbl: Label; var _bet_lbl: Label; var _gain_lbl: Label
var _hand_row: HBoxContainer
var _deal_btn: Button; var _draw_btn: Button
var _card_panels: Array = []
var _held_labels: Array = []

const PAYOUTS := [
	["Royal Flush",800],["Straight Flush",50],["Four of a Kind",25],
	["Full House",9],["Flush",6],["Straight",4],
	["Three of a Kind",3],["Two Pair",2],["Jacks or Better",1]
]

func _game_init() -> void:
	game_title = "VIDEO POKER"
	accent_color = ArcadeTheme.C_PURPLE

func _game_ready() -> void:

	var vbox := VBoxContainer.new(); vbox.add_theme_constant_override("separation",12)
	_content.add_child(vbox)
	var hud := make_hud_row([
		{"label":"FICHAS","id":"chips","color":ArcadeTheme.C_YELLOW,"value":"100"},
		{"label":"APOSTA","id":"bet","color":ArcadeTheme.C_GREEN,"value":"5"},
		{"label":"GANHO","id":"gain","color":ArcadeTheme.C_PURPLE,"value":"0"},
	])
	vbox.add_child(hud)
	_chips_lbl=hud.get_node("chips"); _bet_lbl=hud.get_node("bet"); _gain_lbl=hud.get_node("gain")

	# Table area
	var table:=PanelContainer.new()
	table.add_theme_stylebox_override("panel", ArcadeTheme.panel_style(Color(0,0.08,0.04),Color(0,0.25,0.12,0.5)))
	var tv:=VBoxContainer.new(); tv.add_theme_constant_override("separation",8)
	var hand_lbl:=Label.new(); hand_lbl.text="SUA MÃO"
	hand_lbl.add_theme_font_size_override("font_size",11); hand_lbl.add_theme_color_override("font_color",ArcadeTheme.C_DIM)
	tv.add_child(hand_lbl)
	_hand_row=HBoxContainer.new(); _hand_row.add_theme_constant_override("separation",10)
	_hand_row.alignment=BoxContainer.ALIGNMENT_CENTER
	for i in 5:
		var vb:=VBoxContainer.new(); vb.add_theme_constant_override("separation",4); vb.alignment=BoxContainer.ALIGNMENT_CENTER
		var held_lbl:=Label.new(); held_lbl.text=""; held_lbl.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
		held_lbl.add_theme_font_size_override("font_size",9); held_lbl.add_theme_color_override("font_color",ArcadeTheme.C_YELLOW)
		vb.add_child(held_lbl); _held_labels.append(held_lbl)
		var cp:=PanelContainer.new(); cp.custom_minimum_size=Vector2(64,96)
		cp.add_theme_stylebox_override("panel",ArcadeTheme.panel_style(ArcadeTheme.C_PANEL2,ArcadeTheme.C_BORDER,6))
		var inner:=VBoxContainer.new(); inner.alignment=BoxContainer.ALIGNMENT_CENTER
		cp.add_child(inner); _card_panels.append(inner)
		var idx:=i; cp.gui_input.connect(func(ev): if ev is InputEventMouseButton and ev.pressed and ev.button_index==1 and phase=="hold": _toggle_hold(idx))
		cp.mouse_filter=Control.MOUSE_FILTER_STOP
		vb.add_child(cp); _hand_row.add_child(vb)
	tv.add_child(_hand_row); table.add_child(tv); vbox.add_child(table)

	# Payout table
	var pay_grid:=GridContainer.new(); pay_grid.columns=2; pay_grid.add_theme_constant_override("h_separation",20)
	for p in PAYOUTS:
		var nl:=Label.new(); nl.text=p[0]; nl.add_theme_font_size_override("font_size",11); nl.add_theme_color_override("font_color",ArcadeTheme.C_DIM); pay_grid.add_child(nl)
		var ml:=Label.new(); ml.text=str(p[1])+"×"; ml.add_theme_font_size_override("font_size",11); ml.add_theme_color_override("font_color",ArcadeTheme.C_YELLOW); pay_grid.add_child(ml)
	vbox.add_child(pay_grid)

	var btn_row:=HBoxContainer.new(); btn_row.add_theme_constant_override("separation",10)
	_deal_btn=make_gbtn("DEAL", ArcadeTheme.C_GREEN); _deal_btn.pressed.connect(_deal); btn_row.add_child(_deal_btn)
	_draw_btn=make_gbtn("DRAW", ArcadeTheme.C_PURPLE); _draw_btn.pressed.connect(_draw); _draw_btn.visible=false; btn_row.add_child(_draw_btn)
	var reset_btn:=make_gbtn("RESET", ArcadeTheme.C_DIM); reset_btn.pressed.connect(func(): chips=100; _chips_lbl.text="100"; set_status("Fichas repostas")); btn_row.add_child(reset_btn)
	vbox.add_child(btn_row)
	var hint:=Label.new(); hint.text="DEAL → clique nas cartas para HOLD → DRAW"
	hint.add_theme_font_size_override("font_size",10); hint.add_theme_color_override("font_color",ArcadeTheme.C_DIM); vbox.add_child(hint)
	set_status("Pressione DEAL para jogar")

func _make_deck() -> void:
	deck=[]
	for s in SUITS: for r in RANKS: deck.append({"r":r,"s":s})
	deck.shuffle()

func _deal() -> void:
	if chips<bet: set_status("FICHAS INSUFICIENTES!", ArcadeTheme.C_RED); return
	chips-=bet; _chips_lbl.text=str(chips); _gain_lbl.text="0"
	_make_deck(); hand=[]; for _i in 5: hand.append(deck.pop_back())
	held=[false,false,false,false,false]; phase="hold"
	_deal_btn.visible=false; _draw_btn.visible=true
	_render_hand(); set_status("Clique nas cartas para HOLD, depois DRAW")

func _toggle_hold(i:int) -> void:
	held[i]=!held[i]; _render_hand()

func _draw() -> void:
	for i in 5:
		if not held[i]: hand[i]=deck.pop_back()
	phase="result"; _deal_btn.visible=true; _draw_btn.visible=false
	held=[false,false,false,false,false]; _render_hand()
	var result:=_eval_hand()
	var gain:=bet*result[1]; chips+=gain; _chips_lbl.text=str(chips); _gain_lbl.text=str(gain) if gain>0 else "0"
	if gain>0: set_status("🏆 "+result[0]+"! +"+str(gain), ArcadeTheme.C_GREEN)
	else: set_status("😢 SEM COMBINAÇÃO")
	if chips<=0: chips=100; _chips_lbl.text="100"; set_status("💀 FALIU! Fichas repostas.")

func _eval_hand() -> Array:
	var rv:=func(r): return RANKS.find(r)
	var ranks:=hand.map(func(c): return rv.call(c["r"])); ranks.sort()
	var suits:=hand.map(func(c): return c["s"])
	var flush:=suits.all(func(s): return s==suits[0])
	var straight: bool = ranks[-1]-ranks[0]==4 and ranks.reduce(func(a,b): return a if a==b-1 else -99)!=-99
	# Actually simpler straight check:
	var is_straight:=true; for i in range(1,5): if ranks[i]!=ranks[i-1]+1: is_straight=false; break
	var cnt: Dictionary = {}; for r in ranks: cnt[r] = (cnt.get(r, 0) as int) + 1
	var counts:=cnt.values(); counts.sort(); counts.reverse()
	if flush and is_straight and ranks[0]==8: return ["Royal Flush",800]
	if flush and is_straight: return ["Straight Flush",50]
	if counts[0]==4: return ["Four of a Kind",25]
	if counts[0]==3 and counts[1]==2: return ["Full House",9]
	if flush: return ["Flush",6]
	if is_straight: return ["Straight",4]
	if counts[0]==3: return ["Three of a Kind",3]
	if counts[0]==2 and counts[1]==2: return ["Two Pair",2]
	if counts[0]==2:
		for k in cnt: if cnt[k]==2 and k>=9: return ["Jacks or Better",1]
	return ["",0]

func _render_hand() -> void:
	for i in 5:
		var inner: VBoxContainer = _card_panels[i]; for c in inner.get_children(): c.queue_free()
		var hl: Label = _held_labels[i]; hl.text="HOLD" if held[i] else ""
		if hand.is_empty(): continue
		var card: Dictionary = hand[i]; var is_red: bool = card["s"] in RED_SUITS
		var col:=ArcadeTheme.C_RED if is_red else ArcadeTheme.C_TEXT
		var parent:=inner.get_parent()
		var border_col:=ArcadeTheme.C_YELLOW if held[i] else ArcadeTheme.C_BORDER
		parent.add_theme_stylebox_override("panel",ArcadeTheme.panel_style(
			Color(0.12,0.10,0) if held[i] else ArcadeTheme.C_PANEL2, border_col,6))
		var rl:=Label.new(); rl.text=card["r"]; rl.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
		rl.add_theme_font_size_override("font_size",16); rl.add_theme_color_override("font_color",col)
		var sl:=Label.new(); sl.text=card["s"]; sl.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
		sl.add_theme_font_size_override("font_size",24); sl.add_theme_color_override("font_color",col)
		inner.add_child(rl); inner.add_child(sl)
