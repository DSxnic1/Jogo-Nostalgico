extends BaseGame
# ─────────────────────────────────────
#  Connect4.gd
# ─────────────────────────────────────

const ROWS := 6; const COLS := 7
const CELL := 68.0; const PAD := 8.0

var board: Array = []
var turn: int = 1   # 1=player, 2=cpu
var game_over: bool = false
var _canvas: Control

func _game_init() -> void:
	game_title = "CONNECT 4"
	accent_color = ArcadeTheme.C_BLUE

func _game_ready() -> void:

	var vbox := VBoxContainer.new(); vbox.add_theme_constant_override("separation",12)
	_content.add_child(vbox)
	_canvas = Control.new()
	_canvas.custom_minimum_size = Vector2(COLS*CELL+PAD*2, ROWS*CELL+PAD*2+CELL)
	_canvas.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	_canvas.draw.connect(_draw_board)
	_canvas.gui_input.connect(_on_input)
	_canvas.mouse_filter = Control.MOUSE_FILTER_STOP
	vbox.add_child(_canvas)
	var btn := make_gbtn("NOVO JOGO", ArcadeTheme.C_BLUE); btn.pressed.connect(start_game)
	vbox.add_child(btn)
	var hint := Label.new(); hint.text = "Clique na coluna para jogar"
	hint.add_theme_font_size_override("font_size",11); hint.add_theme_color_override("font_color",ArcadeTheme.C_DIM)
	vbox.add_child(hint)
	start_game()

func start_game() -> void:
	board=[]; for _r in range(ROWS): board.append(Array()); for _c in range(COLS): board[-1].append(0)
	turn=1; game_over=false; set_status("VEZ DO JOGADOR 🔴"); _canvas.queue_redraw()

func _on_input(event:InputEvent) -> void:
	if not (event is InputEventMouseButton and event.pressed and event.button_index==1): return
	if game_over or turn==2: return
	var col := int((event.position.x - PAD) / CELL)
	if col < 0 or col >= COLS: return
	_drop(col)

func _drop(col:int) -> void:
	var row := -1
	for r in range(ROWS-1,-1,-1):
		if board[r][col]==0: row=r; break
	if row==-1: return
	board[row][col]=turn
	_canvas.queue_redraw()
	if _check_win(row,col):
		game_over=true
		var who := "🔴 JOGADOR" if turn==1 else "🟡 CPU"
		set_status(who+" VENCEU! 🏆", ArcadeTheme.C_YELLOW); return
	if _is_draw():
		game_over=true; set_status("🤝 EMPATE!"); return
	turn = 2 if turn==1 else 1
	if turn==2:
		set_status("🤖 CPU PENSANDO...")
		await get_tree().create_timer(0.4).timeout
		_cpu_move()
	else: set_status("VEZ DO JOGADOR 🔴")

func _cpu_move() -> void:
	# Try to win
	for c in range(COLS):
		var r := _top_row(c); if r==-1: continue
		board[r][c]=2
		if _check_win(r,c): _canvas.queue_redraw(); game_over=true; set_status("🤖 CPU VENCEU!",ArcadeTheme.C_RED); return
		board[r][c]=0
	# Block player
	for c in range(COLS):
		var r := _top_row(c); if r==-1: continue
		board[r][c]=1
		if _check_win(r,c): board[r][c]=2; turn=1; set_status("VEZ DO JOGADOR 🔴"); _canvas.queue_redraw(); return
		board[r][c]=0
	# Centre preference
	var pref := [3,2,4,1,5,0,6]
	for c in pref:
		if _top_row(c)!=-1: _drop(c); return

func _top_row(col:int) -> int:
	for r in range(ROWS-1,-1,-1):
		if board[r][col]==0: return r
	return -1

func _check_win(r:int,c:int) -> bool:
	var t: int = board[r][c]
	for dir in [[0,1],[1,0],[1,1],[1,-1]]:
		var cnt := 1
		for s in [1,-1]:
			var nr:=r+dir[0]*s; var nc:=c+dir[1]*s
			while nr>=0 and nr<ROWS and nc>=0 and nc<COLS and board[nr][nc]==t:
				cnt+=1; nr+=dir[0]*s; nc+=dir[1]*s
		if cnt>=4: return true
	return false

func _is_draw() -> bool:
	return board[0].all(func(v): return v!=0)

func _draw_board() -> void:
	var cv := _canvas
	var bw := COLS*CELL+PAD*2; var bh := ROWS*CELL+PAD*2
	cv.draw_rect(Rect2(0,0,bw+PAD*2, bh+CELL), ArcadeTheme.C_BG)
	# Board background
	cv.draw_rect(Rect2(0,CELL,bw,bh), Color(0,0.12,0.25,0.8))
	for r in range(ROWS):
		for c in range(COLS):
			var cx := PAD + c*CELL + CELL/2; var cy := CELL + PAD + r*CELL + CELL/2
			var v: int = board[r][c]
			var col := ArcadeTheme.C_BG if v==0 else (ArcadeTheme.C_RED if v==1 else ArcadeTheme.C_YELLOW)
			cv.draw_circle(Vector2(cx,cy), CELL/2-6, col)
			if v==0: cv.draw_arc(Vector2(cx,cy), CELL/2-6, 0, TAU, 24, Color(0,0.25,0.5,0.4), 1.5)
