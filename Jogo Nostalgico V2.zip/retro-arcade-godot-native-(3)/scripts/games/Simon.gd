extends BaseGame
# ─────────────────────────────────────
#  Simon.gd
# ─────────────────────────────────────

const COLORS_DEF := [
	{"name":"VERDE",    "on":ArcadeTheme.C_GREEN,  "off":Color(0,0.25,0.17)},
	{"name":"VERMELHO", "on":ArcadeTheme.C_RED,    "off":Color(0.25,0.05,0.10)},
	{"name":"AZUL",     "on":ArcadeTheme.C_BLUE,   "off":Color(0,0.18,0.25)},
	{"name":"AMARELO",  "on":ArcadeTheme.C_YELLOW, "off":Color(0.25,0.20,0.05)},
]

var sequence: Array = []
var player_input: Array = []
var round_num: int = 0
var hi: int = 0
var accepting: bool = false
var showing: bool = false
var lit_idx: int = -1
var show_step: int = 0
var show_timer: float = 0.0
var _canvas: Control
var _round_lbl: Label; var _hi_lbl: Label
const BTN_SIZE := 130.0; const BTN_GAP := 16.0

func _game_init() -> void:
	game_title = "SIMON SAYS"
	accent_color = ArcadeTheme.C_PURPLE

func _game_ready() -> void:

	var vbox := VBoxContainer.new(); vbox.add_theme_constant_override("separation",16)
	_content.add_child(vbox)
	var hud := make_hud_row([
		{"label":"RODADA","id":"round","color":ArcadeTheme.C_PURPLE,"value":"0"},
		{"label":"RECORDE","id":"hi","color":ArcadeTheme.C_YELLOW,"value":"0"},
	])
	vbox.add_child(hud)
	_round_lbl = hud.get_node("round"); _hi_lbl = hud.get_node("hi")
	_canvas = Control.new()
	var total := BTN_SIZE*2 + BTN_GAP
	_canvas.custom_minimum_size = Vector2(total, total)
	_canvas.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	_canvas.draw.connect(_draw_simon)
	_canvas.gui_input.connect(_on_canvas_input)
	_canvas.mouse_filter = Control.MOUSE_FILTER_STOP
	vbox.add_child(_canvas)
	var btn := make_gbtn("INICIAR", ArcadeTheme.C_PURPLE); btn.pressed.connect(start_game)
	vbox.add_child(btn)
	var hint := Label.new(); hint.text = "Observe e repita a sequência de cores"
	hint.add_theme_font_size_override("font_size",11); hint.add_theme_color_override("font_color",ArcadeTheme.C_DIM)
	vbox.add_child(hint)
	set_status("PRESSIONE INICIAR")

func start_game() -> void:
	sequence=[randi()%4]; player_input=[]; round_num=0; accepting=false
	set_status("OBSERVE!")
	_show_sequence()

func _show_sequence() -> void:
	showing=true; accepting=false; show_step=0; show_timer=0.0; lit_idx=-1

func _process(delta:float) -> void:
	if not showing: return
	show_timer += delta
	var step_dur := 0.45
	var off_dur  := 0.15
	var total := step_dur + off_dur
	var t := fmod(show_timer, total)
	var step := int(show_timer / total)
	if step >= sequence.size():
		showing=false; lit_idx=-1; accepting=true
		set_status("SUA VEZ!"); _canvas.queue_redraw(); return
	lit_idx = sequence[step] if t < step_dur else -1
	_canvas.queue_redraw()

func _on_canvas_input(event:InputEvent) -> void:
	if not accepting: return
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		var idx := _btn_at(event.position)
		if idx < 0: return
		player_input.append(idx)
		var pos := player_input.size()-1
		if player_input[pos] != sequence[pos]:
			accepting=false
			if sequence.size()-1 > hi: hi=sequence.size()-1; _hi_lbl.text=str(hi)
			set_status("❌ ERROU!  RODADA: "+str(sequence.size()), ArcadeTheme.C_RED)
			return
		if player_input.size() == sequence.size():
			player_input=[]
			round_num=sequence.size(); _round_lbl.text=str(round_num)
			set_status("✓ CORRETO!")
			sequence.append(randi()%4)
			await get_tree().create_timer(0.8).timeout
			set_status("OBSERVE!")
			_show_sequence()

func _btn_at(pos:Vector2) -> int:
	var rects := _get_rects()
	for i in rects.size():
		if rects[i].has_point(pos): return i
	return -1

func _get_rects() -> Array:
	return [
		Rect2(0, 0, BTN_SIZE, BTN_SIZE),
		Rect2(BTN_SIZE+BTN_GAP, 0, BTN_SIZE, BTN_SIZE),
		Rect2(0, BTN_SIZE+BTN_GAP, BTN_SIZE, BTN_SIZE),
		Rect2(BTN_SIZE+BTN_GAP, BTN_SIZE+BTN_GAP, BTN_SIZE, BTN_SIZE),
	]

func _draw_simon() -> void:
	var cv := _canvas
	var rects := _get_rects()
	for i in 4:
		var r: Rect2 = rects[i]
		var lit := (lit_idx == i)
		var col: Color = COLORS_DEF[i]["on"] if lit else COLORS_DEF[i]["off"]
		cv.draw_rect(r, col, true, 0, false)
		cv.draw_rect(r, Color(1,1,1,0.15) if lit else ArcadeTheme.C_BORDER, false, 2)
