extends BaseGame
# ─────────────────────────────────────
#  Memory.gd  —  Jogo da Memória
# ─────────────────────────────────────

const EMOJIS := ["🎮","🕹️","👾","🚀","⭐","💎","🔥","🎯"]
const COLS := 4; const ROWS := 4
const CARD_W := 90.0; const CARD_H := 90.0; const GAP := 10.0

var cards: Array = []   # {emoji, flipped, matched, idx}
var flipped: Array = []
var matched: int = 0
var tries: int = 0
var can_flip: bool = true
var _canvas: Control
var _pairs_lbl: Label; var _tries_lbl: Label

func _game_init() -> void:
	game_title = "MEMÓRIA"
	accent_color = ArcadeTheme.C_YELLOW

func _game_ready() -> void:

	var vbox := VBoxContainer.new(); vbox.add_theme_constant_override("separation",12)
	_content.add_child(vbox)
	var hud := make_hud_row([
		{"label":"PARES","id":"pairs","color":ArcadeTheme.C_GREEN,"value":"0/8"},
		{"label":"TENTATIVAS","id":"tries","color":ArcadeTheme.C_BLUE,"value":"0"},
	])
	vbox.add_child(hud)
	_pairs_lbl=hud.get_node("pairs"); _tries_lbl=hud.get_node("tries")
	_canvas = Control.new()
	var w:=(CARD_W+GAP)*COLS-GAP; var h:=(CARD_H+GAP)*ROWS-GAP
	_canvas.custom_minimum_size=Vector2(w,h); _canvas.size_flags_horizontal=Control.SIZE_SHRINK_CENTER
	_canvas.draw.connect(_draw_cards); _canvas.gui_input.connect(_on_input)
	_canvas.mouse_filter=Control.MOUSE_FILTER_STOP
	vbox.add_child(_canvas)
	var btn:=make_gbtn("NOVO JOGO",ArcadeTheme.C_YELLOW); btn.pressed.connect(start_game)
	vbox.add_child(btn); start_game()

func start_game() -> void:
	var deck:=EMOJIS.duplicate()+EMOJIS.duplicate(); deck.shuffle()
	cards=[]; flipped=[]; matched=0; tries=0; can_flip=true
	_pairs_lbl.text="0/8"; _tries_lbl.text="0"; set_status("")
	for i in deck.size(): cards.append({"emoji":deck[i],"flipped":false,"matched":false,"idx":i})
	_canvas.queue_redraw()

func _on_input(event:InputEvent) -> void:
	if not (event is InputEventMouseButton and event.pressed and event.button_index==1): return
	if not can_flip: return
	var c:=int(event.position.x/(CARD_W+GAP)); var r:=int(event.position.y/(CARD_H+GAP))
	var i:=r*COLS+c
	if i<0 or i>=cards.size(): return
	if cards[i]["flipped"] or cards[i]["matched"]: return
	if flipped.size()>=2: return
	cards[i]["flipped"]=true; flipped.append(i); _canvas.queue_redraw()
	if flipped.size()==2:
		tries+=1; _tries_lbl.text=str(tries); can_flip=false
		await get_tree().create_timer(0.7).timeout
		var a: Dictionary = flipped[0]; var b: Dictionary = flipped[1]
		if cards[a]["emoji"]==cards[b]["emoji"]:
			cards[a]["matched"]=true; cards[b]["matched"]=true; matched+=1
			_pairs_lbl.text=str(matched)+"/8"
			if matched==8: set_status("🏆 PARABÉNS! "+str(tries)+" TENTATIVAS!", ArcadeTheme.C_GREEN)
		else: cards[a]["flipped"]=false; cards[b]["flipped"]=false
		flipped=[]; can_flip=true; _canvas.queue_redraw()

func _draw_cards() -> void:
	var cv:=_canvas
	for i in cards.size():
		var c:=i%COLS; var r:=i/COLS
		var rx:=c*(CARD_W+GAP); var ry:=r*(CARD_H+GAP)
		var rect:=Rect2(rx,ry,CARD_W,CARD_H)
		var cd: Dictionary = cards[i]
		if cd["matched"]:
			cv.draw_rect(rect,Color(0,0.2,0.1),true); cv.draw_rect(rect,ArcadeTheme.C_GREEN,false,2)
			cv.draw_string(ThemeDB.fallback_font,Vector2(rx+20,ry+CARD_H-20),cd["emoji"],HORIZONTAL_ALIGNMENT_LEFT,-1,42)
		elif cd["flipped"]:
			cv.draw_rect(rect,ArcadeTheme.C_PANEL2); cv.draw_rect(rect,ArcadeTheme.C_BLUE,false,2)
			cv.draw_string(ThemeDB.fallback_font,Vector2(rx+20,ry+CARD_H-20),cd["emoji"],HORIZONTAL_ALIGNMENT_LEFT,-1,42)
		else:
			cv.draw_rect(rect,ArcadeTheme.C_PANEL); cv.draw_rect(rect,ArcadeTheme.C_BORDER,false,1)
			cv.draw_string(ThemeDB.fallback_font,Vector2(rx+CARD_W/2-8,ry+CARD_H/2+8),"?",HORIZONTAL_ALIGNMENT_LEFT,-1,24,ArcadeTheme.C_DIM)
