extends BaseGame
# ─────────────────────────────────────
#  Blackjack.gd
# ─────────────────────────────────────

const SUITS := ["♠","♥","♦","♣"]
const RANKS := ["A","2","3","4","5","6","7","8","9","10","J","Q","K"]
const RED_SUITS := ["♥","♦"]

var chips: int = 1000
var bet: int = 0
var deck: Array = []
var player_hand: Array = []
var dealer_hand: Array = []
var phase: String = "bet"   # bet, play, dealer, over
var wins: int = 0

var _chips_lbl: Label; var _bet_lbl: Label; var _wins_lbl: Label
var _dealer_area: VBoxContainer; var _player_area: VBoxContainer
var _action_row: HBoxContainer

func _game_init() -> void:
	game_title = "BLACKJACK"
	accent_color = ArcadeTheme.C_GREEN

func _game_ready() -> void:

	var vbox := VBoxContainer.new(); vbox.add_theme_constant_override("separation",12)
	_content.add_child(vbox)

	var hud := make_hud_row([
		{"label":"FICHAS","id":"chips","color":ArcadeTheme.C_YELLOW,"value":"1000"},
		{"label":"APOSTA","id":"bet","color":ArcadeTheme.C_GREEN,"value":"0"},
		{"label":"VITÓRIAS","id":"wins","color":ArcadeTheme.C_BLUE,"value":"0"},
	])
	vbox.add_child(hud)
	_chips_lbl=hud.get_node("chips"); _bet_lbl=hud.get_node("bet"); _wins_lbl=hud.get_node("wins")

	# Table
	var table := PanelContainer.new()
	var ts := ArcadeTheme.panel_style(Color(0,0.1,0.05), Color(0,0.3,0.15,0.5))
	table.add_theme_stylebox_override("panel",ts)
	var tv := VBoxContainer.new(); tv.add_theme_constant_override("separation",10)
	table.add_child(tv)

	var dl := Label.new(); dl.text="DEALER"; dl.add_theme_font_size_override("font_size",11); dl.add_theme_color_override("font_color",ArcadeTheme.C_DIM); tv.add_child(dl)
	_dealer_area = VBoxContainer.new(); _dealer_area.add_theme_constant_override("separation",4); tv.add_child(_dealer_area)
	var pl := Label.new(); pl.text="VOCÊ"; pl.add_theme_font_size_override("font_size",11); pl.add_theme_color_override("font_color",ArcadeTheme.C_DIM); tv.add_child(pl)
	_player_area = VBoxContainer.new(); _player_area.add_theme_constant_override("separation",4); tv.add_child(_player_area)
	vbox.add_child(table)

	# Chip row
	var chip_row := HBoxContainer.new(); chip_row.add_theme_constant_override("separation",8)
	var cl := Label.new(); cl.text="APOSTAR:"; cl.add_theme_font_size_override("font_size",12); cl.add_theme_color_override("font_color",ArcadeTheme.C_DIM); chip_row.add_child(cl)
	for v in [5,10,25,50,100]:
		var b:=make_gbtn("$"+str(v), ArcadeTheme.C_YELLOW); b.custom_minimum_size=Vector2(60,36)
		b.pressed.connect(func(): _add_bet(v)); chip_row.add_child(b)
	var deal_b:=make_gbtn("DEAL", ArcadeTheme.C_GREEN); deal_b.pressed.connect(_deal); chip_row.add_child(deal_b)
	vbox.add_child(chip_row)

	# Action row
	_action_row = HBoxContainer.new(); _action_row.add_theme_constant_override("separation",8)
	var hit_b:=make_gbtn("HIT", ArcadeTheme.C_GREEN); hit_b.pressed.connect(_hit); _action_row.add_child(hit_b)
	var stand_b:=make_gbtn("STAND", ArcadeTheme.C_BLUE); stand_b.pressed.connect(_stand); _action_row.add_child(stand_b)
	var dbl_b:=make_gbtn("DOUBLE", ArcadeTheme.C_ORANGE); dbl_b.pressed.connect(_double); _action_row.add_child(dbl_b)
	var new_b:=make_gbtn("NOVA RODADA", ArcadeTheme.C_DIM); new_b.pressed.connect(_new_round); _action_row.add_child(new_b)
	_action_row.visible=false; vbox.add_child(_action_row)
	var hint:=Label.new(); hint.text="HIT: mais carta  |  STAND: parar  |  DOUBLE: dobrar"
	hint.add_theme_font_size_override("font_size",10); hint.add_theme_color_override("font_color",ArcadeTheme.C_DIM); vbox.add_child(hint)
	set_status("Aposte para começar")

func _make_deck() -> void:
	deck=[]
	for s in SUITS: for r in RANKS: deck.append({"r":r,"s":s})
	deck.shuffle()

func _card_val(hand:Array, hide_second:bool=false) -> int:
	var v:=0; var aces:=0
	for i in hand.size():
		if hide_second and i==1: continue
		var c: Dictionary = hand[i]
		if c["r"] in ["J","Q","K"]: v+=10
		elif c["r"]=="A": v+=11; aces+=1
		else: v+=int(c["r"])
	while v>21 and aces>0: v-=10; aces-=1
	return v

func _add_bet(amount:int) -> void:
	if phase!="bet": return
	if bet+amount>chips: return
	bet+=amount; _bet_lbl.text=str(bet); set_status("Aposta: $"+str(bet)+" — Clique DEAL")

func _deal() -> void:
	if phase!="bet" or bet==0: return
	_make_deck(); chips-=bet; _chips_lbl.text=str(chips)
	player_hand=[deck.pop_back(),deck.pop_back()]
	dealer_hand=[deck.pop_back(),deck.pop_back()]
	phase="play"; _render_hands(false); _action_row.visible=true
	set_status("Sua vez — Total: "+str(_card_val(player_hand)))
	if _card_val(player_hand)==21: _stand()

func _hit() -> void:
	if phase!="play": return
	player_hand.append(deck.pop_back()); _render_hands(false)
	var pv:=_card_val(player_hand); set_status("Total: "+str(pv))
	if pv>21: _resolve(false)
	elif pv==21: _stand()

func _stand() -> void:
	if phase!="play": return
	phase="dealer"; _render_hands(true)
	await get_tree().create_timer(0.5).timeout
	while _card_val(dealer_hand)<17:
		dealer_hand.append(deck.pop_back()); _render_hands(true)
		await get_tree().create_timer(0.5).timeout
	_resolve(true)

func _double() -> void:
	if phase!="play" or bet>chips: return
	chips-=bet; bet*=2; _bet_lbl.text=str(bet); _chips_lbl.text=str(chips)
	player_hand.append(deck.pop_back()); _render_hands(false); _stand()

func _resolve(show_dealer:bool) -> void:
	phase="over"; _render_hands(true)
	var pv:=_card_val(player_hand); var dv:=_card_val(dealer_hand)
	var msg:=""
	if pv>21: msg="😢 BUST! -$"+str(bet); chips-=0  # already deducted
	elif dv>21: msg="🏆 DEALER BUST! +$"+str(bet); chips+=bet*2; wins+=1
	elif pv>dv: msg="🏆 VOCÊ GANHOU! +$"+str(bet); chips+=bet*2; wins+=1
	elif pv<dv: msg="😢 DEALER VENCEU! -$"+str(bet)
	else: msg="🤝 EMPATE!"; chips+=bet
	_chips_lbl.text=str(chips); _wins_lbl.text=str(wins); set_status(msg)
	if chips<=0: chips=1000; _chips_lbl.text="1000"; set_status("💀 FALIU! Fichas repostas.")

func _new_round() -> void:
	bet=0; phase="bet"; player_hand=[]; dealer_hand=[]
	_bet_lbl.text="0"; _action_row.visible=false
	_dealer_area.get_children().map(func(c): c.queue_free())
	_player_area.get_children().map(func(c): c.queue_free())
	set_status("Aposte para começar")

func _render_hands(show_dealer:bool) -> void:
	for c in _dealer_area.get_children(): c.queue_free()
	for c in _player_area.get_children(): c.queue_free()
	_render_hand(_dealer_area, dealer_hand, show_dealer)
	_render_hand(_player_area, player_hand, true)

func _render_hand(area:VBoxContainer, hand:Array, show_all:bool) -> void:
	var row := HBoxContainer.new(); row.add_theme_constant_override("separation",6)
	for i in hand.size():
		var c: Dictionary = hand[i]; var is_red: bool = c["s"] in RED_SUITS
		var card_panel := PanelContainer.new()
		card_panel.custom_minimum_size = Vector2(56,82)
		var cs:StyleBoxFlat
		if not show_all and i==1: cs=ArcadeTheme.panel_style(Color(0.05,0.05,0.15), ArcadeTheme.C_BORDER)
		else: cs=ArcadeTheme.panel_style(Color(0.10,0.10,0.22), ArcadeTheme.C_BORDER)
		card_panel.add_theme_stylebox_override("panel",cs)
		var cv := VBoxContainer.new(); cv.alignment=BoxContainer.ALIGNMENT_CENTER
		if not show_all and i==1:
			var hl := Label.new(); hl.text="?"; hl.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
			hl.add_theme_font_size_override("font_size",20); hl.add_theme_color_override("font_color",ArcadeTheme.C_DIM)
			cv.add_child(hl)
		else:
			var rl := Label.new(); rl.text=c["r"]; rl.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
			rl.add_theme_font_size_override("font_size",14)
			rl.add_theme_color_override("font_color", ArcadeTheme.C_RED if is_red else ArcadeTheme.C_TEXT)
			var sl := Label.new(); sl.text=c["s"]; sl.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
			sl.add_theme_font_size_override("font_size",20)
			sl.add_theme_color_override("font_color", ArcadeTheme.C_RED if is_red else ArcadeTheme.C_TEXT)
			cv.add_child(rl); cv.add_child(sl)
		card_panel.add_child(cv); row.add_child(card_panel)
	# Score label
	var sv := _card_val(hand, not show_all)
	var sc_lbl := Label.new(); sc_lbl.text=" = "+str(sv)
	sc_lbl.add_theme_font_size_override("font_size",18); sc_lbl.add_theme_color_override("font_color",ArcadeTheme.C_YELLOW)
	row.add_child(sc_lbl); area.add_child(row)
