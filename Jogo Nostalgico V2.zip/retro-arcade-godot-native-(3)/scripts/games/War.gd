extends BaseGame
# ─────────────────────────────────────
#  War.gd  —  Jogo da Guerra
# ─────────────────────────────────────

const SUITS := ["♠","♥","♦","♣"]
const RANKS := ["2","3","4","5","6","7","8","9","10","J","Q","K","A"]
const RED_SUITS := ["♥","♦"]

var my_deck: Array = []
var cpu_deck: Array = []
var round_num: int = 0
var going: bool = false
var _my_lbl: Label; var _cpu_lbl: Label; var _round_lbl: Label
var _my_card_panel: PanelContainer; var _cpu_card_panel: PanelContainer
var _battle_btn: Button

func _game_init() -> void:
	game_title = "GUERRA"
	accent_color = ArcadeTheme.C_BLUE

func _game_ready() -> void:

	var vbox := VBoxContainer.new(); vbox.add_theme_constant_override("separation",14)
	_content.add_child(vbox)
	var hud := make_hud_row([
		{"label":"SUAS CARTAS","id":"my","color":ArcadeTheme.C_GREEN,"value":"26"},
		{"label":"CARTAS CPU","id":"cpu","color":ArcadeTheme.C_RED,"value":"26"},
		{"label":"RODADA","id":"round","color":ArcadeTheme.C_YELLOW,"value":"0"},
	])
	vbox.add_child(hud)
	_my_lbl=hud.get_node("my"); _cpu_lbl=hud.get_node("cpu"); _round_lbl=hud.get_node("round")

	var arena := HBoxContainer.new(); arena.alignment=BoxContainer.ALIGNMENT_CENTER; arena.add_theme_constant_override("separation",30)
	vbox.add_child(arena)

	var my_zone := VBoxContainer.new(); my_zone.alignment=BoxContainer.ALIGNMENT_CENTER; my_zone.add_theme_constant_override("separation",8)
	var ml := Label.new(); ml.text="VOCÊ"; ml.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; ml.add_theme_font_size_override("font_size",12); ml.add_theme_color_override("font_color",ArcadeTheme.C_DIM); my_zone.add_child(ml)
	_my_card_panel=_make_card_panel(); my_zone.add_child(_my_card_panel); arena.add_child(my_zone)

	var vs := Label.new(); vs.text="⚔"; vs.add_theme_font_size_override("font_size",32); vs.add_theme_color_override("font_color",ArcadeTheme.C_DIM); arena.add_child(vs)

	var cpu_zone := VBoxContainer.new(); cpu_zone.alignment=BoxContainer.ALIGNMENT_CENTER; cpu_zone.add_theme_constant_override("separation",8)
	var cpul := Label.new(); cpul.text="CPU"; cpul.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; cpul.add_theme_font_size_override("font_size",12); cpul.add_theme_color_override("font_color",ArcadeTheme.C_DIM); cpu_zone.add_child(cpul)
	_cpu_card_panel=_make_card_panel(); cpu_zone.add_child(_cpu_card_panel); arena.add_child(cpu_zone)

	_battle_btn=make_gbtn("⚔  BATALHAR", ArcadeTheme.C_BLUE); _battle_btn.pressed.connect(_battle); vbox.add_child(_battle_btn)
	var new_btn:=make_gbtn("NOVO JOGO", ArcadeTheme.C_DIM); new_btn.pressed.connect(start_game); vbox.add_child(new_btn)
	var hint:=Label.new(); hint.text="Maior carta vence e fica com as duas cartas"
	hint.add_theme_font_size_override("font_size",11); hint.add_theme_color_override("font_color",ArcadeTheme.C_DIM); vbox.add_child(hint)
	set_status("PRESSIONE BATALHAR!"); start_game()

func _make_card_panel() -> PanelContainer:
	var p:=PanelContainer.new(); p.custom_minimum_size=Vector2(100,140)
	var s:=ArcadeTheme.panel_style(ArcadeTheme.C_PANEL2, ArcadeTheme.C_BORDER, 8); p.add_theme_stylebox_override("panel",s)
	var l:=Label.new(); l.text="🂠"; l.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; l.vertical_alignment=VERTICAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size",40); p.add_child(l); return p

func _show_card(panel:PanelContainer, card:Dictionary, win:bool) -> void:
	for c in panel.get_children(): c.queue_free()
	var is_red: bool = card["s"] in RED_SUITS
	var border:=ArcadeTheme.C_GREEN if win else ArcadeTheme.C_BORDER
	var bg:=Color(0,0.12,0.06) if win else ArcadeTheme.C_PANEL2
	var s:=ArcadeTheme.panel_style(bg, border, 8); panel.add_theme_stylebox_override("panel",s)
	var vb:=VBoxContainer.new(); vb.alignment=BoxContainer.ALIGNMENT_CENTER; vb.add_theme_constant_override("separation",4)
	var rl:=Label.new(); rl.text=card["r"]; rl.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	rl.add_theme_font_size_override("font_size",28); rl.add_theme_color_override("font_color", ArcadeTheme.C_RED if is_red else ArcadeTheme.C_TEXT)
	var sl:=Label.new(); sl.text=card["s"]; sl.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	sl.add_theme_font_size_override("font_size",30); sl.add_theme_color_override("font_color", ArcadeTheme.C_RED if is_red else ArcadeTheme.C_TEXT)
	vb.add_child(rl); vb.add_child(sl); panel.add_child(vb)

func start_game() -> void:
	var full:=[]
	for s in SUITS: for r in RANKS: full.append({"r":r,"s":s})
	full.shuffle(); my_deck=full.slice(0,26); cpu_deck=full.slice(26)
	round_num=0; _my_lbl.text="26"; _cpu_lbl.text="26"; _round_lbl.text="0"; set_status("PRESSIONE BATALHAR!")
	for p in [_my_card_panel,_cpu_card_panel]:
		for c in p.get_children(): c.queue_free()
		var l:=Label.new(); l.text="🂠"; l.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
		l.add_theme_font_size_override("font_size",40); p.add_child(l)

func _battle() -> void:
	if going or my_deck.is_empty() or cpu_deck.is_empty(): return
	going=true; round_num+=1; _round_lbl.text=str(round_num)
	var mc:=my_deck.pop_front(); var cc:=cpu_deck.pop_front()
	var mv:=RANKS.find(mc["r"]); var cv:=RANKS.find(cc["r"])
	var my_win:=mv>cv; var cpu_win:=cv>mv
	_show_card(_my_card_panel, mc, my_win)
	_show_card(_cpu_card_panel, cc, cpu_win)
	var msg:=""
	if my_win: my_deck.append(mc); my_deck.append(cc); msg="✅ VOCÊ VENCEU ESTA RODADA!"
	elif cpu_win: cpu_deck.append(mc); cpu_deck.append(cc); msg="❌ CPU VENCEU!"
	else: my_deck.append(mc); cpu_deck.append(cc); msg="🤝 EMPATE — CADA UM PEGA SUA CARTA"
	_my_lbl.text=str(my_deck.size()); _cpu_lbl.text=str(cpu_deck.size())
	set_status(msg)
	if my_deck.is_empty(): set_status("💀 VOCÊ PERDEU!", ArcadeTheme.C_RED)
	if cpu_deck.is_empty(): set_status("🏆 VOCÊ VENCEU!", ArcadeTheme.C_GREEN)
	going=false
