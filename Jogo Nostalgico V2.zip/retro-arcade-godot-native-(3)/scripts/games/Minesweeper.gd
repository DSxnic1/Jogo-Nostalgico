extends BaseGame
# ─────────────────────────────────────
#  Minesweeper.gd
# ─────────────────────────────────────

var ROWS := 9; var COLS := 9; var MINES := 10
const CELL := 34.0

var board: Array = []      # mine counts, 9=mine
var revealed: Array = []
var flagged: Array = []
var game_over: bool = false
var started: bool = false
var start_time: float = 0.0
var elapsed: float = 0.0
var _canvas: Control
var _mine_lbl: Label; var _time_lbl: Label; var _face_lbl: Label

const NUM_COLORS := [Color(0),
	ArcadeTheme.C_BLUE, ArcadeTheme.C_GREEN, ArcadeTheme.C_RED,
	ArcadeTheme.C_PURPLE, ArcadeTheme.C_ORANGE, ArcadeTheme.C_BLUE,
	Color(0.9,0.9,0.9), ArcadeTheme.C_DIM]

func _game_init() -> void:
	game_title = "CAMPO MINADO"
	accent_color = ArcadeTheme.C_ORANGE

func _game_ready() -> void:

	var vbox := VBoxContainer.new(); vbox.add_theme_constant_override("separation",10)
	_content.add_child(vbox)

	var hud := make_hud_row([
		{"label":"BOMBAS","id":"mines","color":ArcadeTheme.C_RED,"value":"10"},
		{"label":"TEMPO","id":"time","color":ArcadeTheme.C_YELLOW,"value":"0s"},
		{"label":"STATUS","id":"face","color":ArcadeTheme.C_YELLOW,"value":"😐"},
	])
	vbox.add_child(hud)
	_mine_lbl=hud.get_node("mines"); _time_lbl=hud.get_node("time"); _face_lbl=hud.get_node("face")

	# Difficulty buttons
	var diff_hbox := HBoxContainer.new(); diff_hbox.add_theme_constant_override("separation",8)
	for d in [["🟢 FÁCIL",9,9,10],["🟡 MÉDIO",16,16,40],["🔴 DIFÍCIL",16,30,99]]:
		var b := make_gbtn(d[0], ArcadeTheme.C_ORANGE)
		var rows: int = d[1]; var cols: int = d[2]; var mines: int = d[3]
		b.pressed.connect(func(): _set_diff(rows,cols,mines))
		diff_hbox.add_child(b)
	vbox.add_child(diff_hbox)

	var scroll := ScrollContainer.new(); scroll.size_flags_vertical=Control.SIZE_EXPAND_FILL
	_canvas = Control.new(); _canvas.draw.connect(_draw_board)
	_canvas.gui_input.connect(_on_input); _canvas.mouse_filter=Control.MOUSE_FILTER_STOP
	scroll.add_child(_canvas); vbox.add_child(scroll)

	var btn := make_gbtn("REINICIAR", ArcadeTheme.C_ORANGE); btn.pressed.connect(start_game)
	vbox.add_child(btn)
	var hint := Label.new(); hint.text = "CLIQUE: ABRIR  |  CLIQUE DIREITO: BANDEIRA"
	hint.add_theme_font_size_override("font_size",11); hint.add_theme_color_override("font_color",ArcadeTheme.C_DIM)
	vbox.add_child(hint); start_game()

func _set_diff(r:int,c:int,m:int) -> void:
	ROWS=r; COLS=c; MINES=m; start_game()

func start_game() -> void:
	board=[]; revealed=[]; flagged=[]
	for r in range(ROWS):
		board.append([]); revealed.append([]); flagged.append([])
		for _c in range(COLS): board[-1].append(0); revealed[-1].append(false); flagged[-1].append(false)
	game_over=false; started=false; elapsed=0.0
	_mine_lbl.text=str(MINES); _time_lbl.text="0s"; _face_lbl.text="😐"; set_status("")
	_canvas.custom_minimum_size=Vector2(COLS*CELL+4, ROWS*CELL+4)
	_place_mines(); _canvas.queue_redraw()

func _place_mines() -> void:
	var placed:=0
	while placed<MINES:
		var r:=randi()%ROWS; var c:=randi()%COLS
		if board[r][c]!=9: board[r][c]=9; placed+=1
	for r in range(ROWS):
		for c in range(COLS):
			if board[r][c]==9: continue
			var n:=0
			for dr in [-1,0,1]:
				for dc in [-1,0,1]:
					var nr:=r+dr; var nc:=c+dc
					if nr>=0 and nr<ROWS and nc>=0 and nc<COLS and board[nr][nc]==9: n+=1
			board[r][c]=n

func _process(delta:float) -> void:
	if started and not game_over:
		elapsed+=delta; _time_lbl.text=str(int(elapsed))+"s"

func _on_input(event:InputEvent) -> void:
	if game_over: return
	if event is InputEventMouseButton and event.pressed:
		var c:=int(event.position.x/CELL); var r:=int(event.position.y/CELL)
		if r<0 or r>=ROWS or c<0 or c>=COLS: return
		if event.button_index==MOUSE_BUTTON_RIGHT:
			if not revealed[r][c]: flagged[r][c]=!flagged[r][c]
			var fc:=0; for row in flagged: for v in row: if v: fc+=1
			_mine_lbl.text=str(MINES-fc); _canvas.queue_redraw()
		elif event.button_index==MOUSE_BUTTON_LEFT:
			if flagged[r][c]: return
			if not started: started=true
			_open(r,c)

func _open(r:int,c:int) -> void:
	if r<0 or r>=ROWS or c<0 or c>=COLS or revealed[r][c] or flagged[r][c]: return
	revealed[r][c]=true
	if board[r][c]==9:
		game_over=true; _face_lbl.text="💀"
		for rr in range(ROWS):
			for cc in range(COLS):
				if board[rr][cc]==9: revealed[rr][cc]=true
		set_status("💥 BOOM! FIM DE JOGO", ArcadeTheme.C_RED)
	elif board[r][c]==0:
		for dr in [-1,0,1]:
			for dc in [-1,0,1]: _open(r+dr,c+dc)
	var total:=ROWS*COLS; var rev:=0
	for row in revealed: for v in row: if v: rev+=1
	if rev==total-MINES and not game_over:
		game_over=true; _face_lbl.text="🏆"; set_status("🏆 VOCÊ VENCEU!", ArcadeTheme.C_GREEN)
	_canvas.queue_redraw()

func _draw_board() -> void:
	var cv:=_canvas
	cv.draw_rect(Rect2(0,0,COLS*CELL+4,ROWS*CELL+4), ArcadeTheme.C_BG)
	for r in range(ROWS):
		for c in range(COLS):
			var rx:=c*CELL+2; var ry:=r*CELL+2
			var rect:=Rect2(rx,ry,CELL-2,CELL-2)
			if revealed[r][c]:
				cv.draw_rect(rect, ArcadeTheme.C_BG)
				var v: int = board[r][c]
				if v==9:
					cv.draw_rect(rect, Color(0.4,0.05,0.1,0.8))
					cv.draw_rect(Rect2(rx+CELL/2-4,ry+4,8,CELL-10), ArcadeTheme.C_DIM)
					cv.draw_rect(Rect2(rx+4,ry+CELL/2-4,CELL-10,8), ArcadeTheme.C_DIM)
					cv.draw_circle(Vector2(rx+CELL/2,ry+CELL/2), CELL/2-8, Color(0.1,0.1,0.1))
				elif v>0:
					var f:=SystemFont.new()
					# Draw number as colored rect segments
					cv.draw_rect(Rect2(rx+CELL/2-2,ry+4,4,CELL-10), NUM_COLORS[v])
			elif flagged[r][c]:
				cv.draw_rect(rect, ArcadeTheme.C_PANEL2)
				cv.draw_rect(Rect2(rx+CELL/2-2,ry+4,2,CELL-10), ArcadeTheme.C_TEXT)
				cv.draw_rect(Rect2(rx+CELL/2,ry+4,CELL/3,CELL/2-4), ArcadeTheme.C_RED)
			else:
				cv.draw_rect(rect, ArcadeTheme.C_PANEL2)
			cv.draw_rect(rect, ArcadeTheme.C_BORDER, false, 1.0)
			# Number overlay using label trick — draw a small colored square per digit
			if revealed[r][c] and board[r][c]>0 and board[r][c]!=9:
				var v: int = board[r][c]
				# Draw digit-like pattern
				cv.draw_rect(Rect2(rx+CELL/2-5,ry+CELL/2-8,10,16), NUM_COLORS[v])
