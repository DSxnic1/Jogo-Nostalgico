extends BaseGame
# ─────────────────────────────────────
#  Pong.gd
# ─────────────────────────────────────

const W := 640.0
const H := 360.0
const PAD_W := 10.0
const PAD_H := 70.0
const PAD_SPEED := 320.0
const BALL_R := 8.0

var lp_y: float = H/2 - PAD_H/2
var rp_y: float = H/2 - PAD_H/2
var ball_pos: Vector2 = Vector2(W/2, H/2)
var ball_vel: Vector2 = Vector2(220, 130)
var score_l: int = 0
var score_r: int = 0
var running: bool = false
var keys: Dictionary = {}
var _canvas: Control
var _sl_lbl: Label
var _sr_lbl: Label

func _game_init() -> void:
	game_title = "PONG"
	accent_color = ArcadeTheme.C_BLUE

func _game_ready() -> void:

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 12)
	_content.add_child(vbox)

	var hud := make_hud_row([
		{"label":"JOGADOR","id":"sl","color":ArcadeTheme.C_BLUE,"value":"0"},
		{"label":"VS","id":"vs","color":ArcadeTheme.C_DIM,"value":""},
		{"label":"CPU","id":"sr","color":ArcadeTheme.C_RED,"value":"0"},
	])
	vbox.add_child(hud)
	_sl_lbl = hud.get_node("sl")
	_sr_lbl = hud.get_node("sr")

	_canvas = Control.new()
	_canvas.custom_minimum_size = Vector2(W, H)
	_canvas.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	_canvas.draw.connect(_draw_game)
	vbox.add_child(_canvas)

	var btn := make_gbtn("NOVO JOGO", ArcadeTheme.C_BLUE)
	btn.pressed.connect(start_game)
	vbox.add_child(btn)

	var hint := Label.new()
	hint.text = "W / S  ou  ↑ / ↓  para mover"
	hint.add_theme_font_size_override("font_size", 11)
	hint.add_theme_color_override("font_color", ArcadeTheme.C_DIM)
	vbox.add_child(hint)

	start_game()

func start_game() -> void:
	score_l = 0; score_r = 0; running = true
	_sl_lbl.text = "0"; _sr_lbl.text = "0"
	set_status("")
	_reset_ball()

func _reset_ball() -> void:
	ball_pos = Vector2(W/2, H/2)
	var angle := randf_range(-0.4, 0.4)
	var dir := 1.0 if randf() > 0.5 else -1.0
	ball_vel = Vector2(cos(angle)*220*dir, sin(angle)*220)

func _process(delta: float) -> void:
	if not running: return
	# Player paddle
	if keys.get("w") or keys.get("up"):    lp_y = maxf(0, lp_y - PAD_SPEED*delta)
	if keys.get("s") or keys.get("down"):  lp_y = minf(H-PAD_H, lp_y + PAD_SPEED*delta)
	# CPU paddle (simple AI)
	var cpu_center := rp_y + PAD_H/2
	if cpu_center < ball_pos.y - 4: rp_y = minf(H-PAD_H, rp_y + 280*delta)
	if cpu_center > ball_pos.y + 4: rp_y = maxf(0, rp_y - 280*delta)
	# Ball movement
	ball_pos += ball_vel * delta
	# Top/bottom bounce
	if ball_pos.y < BALL_R:         ball_vel.y = abs(ball_vel.y)
	if ball_pos.y > H - BALL_R:     ball_vel.y = -abs(ball_vel.y)
	# Left paddle collision
	if ball_pos.x < 18 + BALL_R and ball_pos.y > lp_y and ball_pos.y < lp_y + PAD_H:
		ball_vel.x = abs(ball_vel.x) * 1.05
		ball_vel.y += (ball_pos.y - (lp_y+PAD_H/2)) * 2.5
	# Right paddle collision
	if ball_pos.x > W - 18 - BALL_R and ball_pos.y > rp_y and ball_pos.y < rp_y + PAD_H:
		ball_vel.x = -abs(ball_vel.x) * 1.05
		ball_vel.y += (ball_pos.y - (rp_y+PAD_H/2)) * 2.5
	# Clamp speed
	ball_vel.x = clampf(ball_vel.x, -480, 480)
	ball_vel.y = clampf(ball_vel.y, -320, 320)
	# Scoring
	if ball_pos.x < 0:
		score_r += 1; _sr_lbl.text = str(score_r)
		if score_r >= 7: _end("🤖 CPU VENCEU!"); return
		_reset_ball()
	if ball_pos.x > W:
		score_l += 1; _sl_lbl.text = str(score_l)
		if score_l >= 7: _end("🏆 VOCÊ VENCEU!"); return
		_reset_ball()
	_canvas.queue_redraw()

func _end(msg: String) -> void:
	running = false
	set_status(msg)
	_canvas.queue_redraw()

func _input(event: InputEvent) -> void:
	if not visible: return
	if event is InputEventKey:
		var k := ""
		match event.keycode:
			KEY_W: k = "w"; KEY_S: k = "s"
			KEY_UP: k = "up"; KEY_DOWN: k = "down"
		if k != "": keys[k] = event.pressed

func _draw_game() -> void:
	var cv := _canvas
	cv.draw_rect(Rect2(0,0,W,H), ArcadeTheme.C_BG)
	# Center dashes
	var dash_h := 14.0
	var y := 0.0
	while y < H:
		cv.draw_rect(Rect2(W/2-1, y, 2, dash_h), Color(1,1,1,0.08))
		y += dash_h * 2
	# Paddles
	cv.draw_rect(Rect2(8, lp_y, PAD_W, PAD_H), ArcadeTheme.C_BLUE)
	cv.draw_rect(Rect2(W-18, rp_y, PAD_W, PAD_H), ArcadeTheme.C_RED)
	# Ball
	cv.draw_circle(ball_pos, BALL_R, ArcadeTheme.C_YELLOW)
	# Border
	cv.draw_rect(Rect2(0,0,W,H), ArcadeTheme.C_BORDER, false, 1.5)
