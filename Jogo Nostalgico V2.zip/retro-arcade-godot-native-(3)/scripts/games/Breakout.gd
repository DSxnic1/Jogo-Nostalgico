extends BaseGame
# ─────────────────────────────────────
#  Breakout.gd
# ─────────────────────────────────────

const W := 560.0
const H := 420.0
const PAD_W := 90.0
const PAD_H := 12.0
const BALL_R := 8.0
const BRICK_COLS := 10
const BRICK_ROWS := 6
const BRICK_W := 52.0
const BRICK_H := 18.0
const BRICK_PAD := 3.0
const BRICK_OFF_X := 4.0
const BRICK_OFF_Y := 40.0

const ROW_COLORS := [
	ArcadeTheme.C_RED, ArcadeTheme.C_ORANGE, ArcadeTheme.C_YELLOW,
	ArcadeTheme.C_GREEN, ArcadeTheme.C_BLUE, ArcadeTheme.C_PURPLE
]

var pad_x: float = W/2 - PAD_W/2
var ball_pos: Vector2
var ball_vel: Vector2
var bricks: Array = []
var score: int = 0
var lives: int = 3
var level: int = 1
var launched: bool = false
var running: bool = false
var _canvas: Control
var _score_lbl: Label
var _lives_lbl: Label
var _level_lbl: Label

func _game_init() -> void:
	game_title = "BREAKOUT"
	accent_color = ArcadeTheme.C_ORANGE

func _game_ready() -> void:

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	_content.add_child(vbox)

	var hud := make_hud_row([
		{"label":"SCORE","id":"score","color":ArcadeTheme.C_ORANGE,"value":"0"},
		{"label":"VIDAS","id":"lives","color":ArcadeTheme.C_RED,"value":"3"},
		{"label":"NÍVEL","id":"level","color":ArcadeTheme.C_YELLOW,"value":"1"},
	])
	vbox.add_child(hud)
	_score_lbl = hud.get_node("score")
	_lives_lbl = hud.get_node("lives")
	_level_lbl = hud.get_node("level")

	_canvas = Control.new()
	_canvas.custom_minimum_size = Vector2(W, H)
	_canvas.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	_canvas.draw.connect(_draw_game)
	_canvas.gui_input.connect(_on_canvas_input)
	_canvas.mouse_filter = Control.MOUSE_FILTER_STOP
	vbox.add_child(_canvas)

	var hbox := HBoxContainer.new()
	hbox.add_theme_constant_override("separation", 10)
	var btn := make_gbtn("NOVO JOGO", ArcadeTheme.C_ORANGE)
	btn.pressed.connect(start_game)
	hbox.add_child(btn)
	vbox.add_child(hbox)

	var hint := Label.new()
	hint.text = "← →  MOVER  |  ESPAÇO / CLIQUE  LANÇAR"
	hint.add_theme_font_size_override("font_size", 11)
	hint.add_theme_color_override("font_color", ArcadeTheme.C_DIM)
	vbox.add_child(hint)

	start_game()

func start_game() -> void:
	score = 0; lives = 3; level = 1
	_score_lbl.text = "0"; _lives_lbl.text = "3"; _level_lbl.text = "1"
	set_status("")
	_make_bricks()
	_reset_ball()
	running = true

func _make_bricks() -> void:
	bricks = []
	for r in range(BRICK_ROWS):
		for c in range(BRICK_COLS):
			var bx := BRICK_OFF_X + c*(BRICK_W+BRICK_PAD)
			var by := BRICK_OFF_Y + r*(BRICK_H+BRICK_PAD)
			bricks.append({"rect": Rect2(bx,by,BRICK_W,BRICK_H), "alive": true,
				"color": ROW_COLORS[r], "pts": (BRICK_ROWS-r)*10})

func _reset_ball() -> void:
	ball_pos = Vector2(pad_x + PAD_W/2, H - PAD_H - BALL_R - 2)
	ball_vel = Vector2.ZERO
	launched = false

func _process(delta: float) -> void:
	if not running: return
	if Input.is_key_pressed(KEY_LEFT):  pad_x = maxf(0, pad_x - 380*delta)
	if Input.is_key_pressed(KEY_RIGHT): pad_x = minf(W-PAD_W, pad_x + 380*delta)
	if not launched:
		ball_pos.x = pad_x + PAD_W/2
		if Input.is_key_pressed(KEY_SPACE): _launch()
		_canvas.queue_redraw(); return
	ball_pos += ball_vel * delta
	if ball_pos.x < BALL_R:       ball_vel.x = abs(ball_vel.x)
	if ball_pos.x > W - BALL_R:   ball_vel.x = -abs(ball_vel.x)
	if ball_pos.y < BALL_R:       ball_vel.y = abs(ball_vel.y)
	# Paddle
	var pr := Rect2(pad_x, H-PAD_H-2, PAD_W, PAD_H)
	if pr.has_point(ball_pos) and ball_vel.y > 0:
		var rel := (ball_pos.x - (pad_x+PAD_W/2)) / (PAD_W/2)
		ball_vel.x = rel * 300
		ball_vel.y = -abs(ball_vel.y)
	# Bricks
	for b in bricks:
		if not b["alive"]: continue
		if b["rect"].has_point(ball_pos):
			b["alive"] = false
			ball_vel.y *= -1
			score += b["pts"]
			_score_lbl.text = str(score)
	if bricks.all(func(b): return not b["alive"]):
		level += 1; _level_lbl.text = str(level)
		_make_bricks(); _reset_ball()
	# Lost ball
	if ball_pos.y > H + 20:
		lives -= 1; _lives_lbl.text = str(lives)
		if lives <= 0:
			running = false; set_status("💀 GAME OVER!  SCORE: " + str(score), ArcadeTheme.C_RED)
		else: _reset_ball()
	_canvas.queue_redraw()

func _launch() -> void:
	launched = true
	var spd := 300.0 + level * 20.0
	ball_vel = Vector2(randf_range(-0.5,0.5), -1).normalized() * spd

func _on_canvas_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion:
		pad_x = clampf(event.position.x - PAD_W/2, 0, W-PAD_W)
	if event is InputEventMouseButton and event.pressed:
		if not launched: _launch()

func _draw_game() -> void:
	var cv := _canvas
	cv.draw_rect(Rect2(0,0,W,H), ArcadeTheme.C_BG)
	for b in bricks:
		if not b["alive"]: continue
		cv.draw_rect(b["rect"], b["color"])
		cv.draw_rect(Rect2(b["rect"].position + Vector2(2,2), Vector2(b["rect"].size.x-4, 3)), Color(1,1,1,0.2))
	cv.draw_rect(Rect2(pad_x, H-PAD_H-2, PAD_W, PAD_H), ArcadeTheme.C_BLUE)
	cv.draw_circle(ball_pos, BALL_R, ArcadeTheme.C_YELLOW)
	cv.draw_rect(Rect2(0,0,W,H), ArcadeTheme.C_BORDER, false, 1.5)
