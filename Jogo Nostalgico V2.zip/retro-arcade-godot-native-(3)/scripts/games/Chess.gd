extends BaseGame
# ─────────────────────────────────────
#  Chess.gd
# ─────────────────────────────────────

const CELL := 56.0
const LIGHT := Color(0.12, 0.12, 0.22)
const DARK  := Color(0.06, 0.06, 0.14)
const SEL_COL   := Color(0.75, 0.37, 1.0, 0.45)
const HINT_COL  := Color(0.0,  1.0,  0.67, 0.30)

const INIT_BOARD := [
	["bR","bN","bB","bQ","bK","bB","bN","bR"],
	["bP","bP","bP","bP","bP","bP","bP","bP"],
	["","","","","","","",""],["","","","","","","",""],
	["","","","","","","",""],["","","","","","","",""],
	["wP","wP","wP","wP","wP","wP","wP","wP"],
	["wR","wN","wB","wQ","wK","wB","wN","wR"],
]

const GLYPH := {
	"wK":"♔","wQ":"♕","wR":"♖","wB":"♗","wN":"♘","wP":"♙",
	"bK":"♚","bQ":"♛","bR":"♜","bB":"♝","bN":"♞","bP":"♟"
}

var board: Array = []
var sel: Vector2i = Vector2i(-1,-1)
var moves: Array = []
var turn: String = "w"
var _canvas: Control
var _status_lbl2: Label

func _game_init() -> void:
	game_title = "XADREZ"
	accent_color = ArcadeTheme.C_PURPLE

func _game_ready() -> void:

	var vbox := VBoxContainer.new(); vbox.add_theme_constant_override("separation",12)
	_content.add_child(vbox)
	_canvas = Control.new()
	_canvas.custom_minimum_size = Vector2(8*CELL, 8*CELL)
	_canvas.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	_canvas.draw.connect(_draw_board)
	_canvas.gui_input.connect(_on_input)
	_canvas.mouse_filter = Control.MOUSE_FILTER_STOP
	vbox.add_child(_canvas)
	var btn := make_gbtn("NOVO JOGO", ArcadeTheme.C_PURPLE); btn.pressed.connect(start_game)
	vbox.add_child(btn)
	var hint := Label.new(); hint.text = "Clique para selecionar • Clique no destino para mover"
	hint.add_theme_font_size_override("font_size",11); hint.add_theme_color_override("font_color",ArcadeTheme.C_DIM)
	vbox.add_child(hint)
	start_game()

func start_game() -> void:
	board = INIT_BOARD.map(func(r): return r.duplicate())
	sel=Vector2i(-1,-1); moves=[]; turn="w"
	set_status("VEZ DAS BRANCAS ♔", ArcadeTheme.C_BLUE)
	_canvas.queue_redraw()

func _on_input(event:InputEvent) -> void:
	if not (event is InputEventMouseButton and event.pressed and event.button_index==1): return
	var c:=int(event.position.x/CELL); var r:=int(event.position.y/CELL)
	if r<0 or r>=8 or c<0 or c>=8: return
	var pos:=Vector2i(c,r)
	# If a move target
	if sel!=Vector2i(-1,-1) and pos in moves:
		_move(sel, pos); return
	# Select piece
	var p: String = board[r][c]
	if p!="" and p.substr(0,1)==turn:
		sel=pos; moves=_get_moves(r,c)
	else: sel=Vector2i(-1,-1); moves=[]
	_canvas.queue_redraw()

func _move(from:Vector2i, to:Vector2i) -> void:
	board[to.y][to.x]=board[from.y][from.x]; board[from.y][from.x]=""
	# Promote pawn
	if board[to.y][to.x]=="wP" and to.y==0: board[to.y][to.x]="wQ"
	if board[to.y][to.x]=="bP" and to.y==7: board[to.y][to.x]="bQ"
	turn = "b" if turn=="w" else "w"
	sel=Vector2i(-1,-1); moves=[]
	set_status(("VEZ DAS BRANCAS ♔" if turn=="w" else "VEZ DAS PRETAS ♚"), ArcadeTheme.C_BLUE)
	_canvas.queue_redraw()

func _get_moves(r:int,c:int) -> Array:
	var p: String = board[r][c]; if p=="": return []
	var col:=p.substr(0,1); var type:=p.substr(1,1)
	var res:=[]
	var add=func(nr,nc):
		if nr<0 or nr>=8 or nc<0 or nc>=8: return false
		if board[nr][nc]!="" and board[nr][nc].substr(0,1)==col: return false
		res.append(Vector2i(nc,nr))
		return board[nr][nc]==""
	var slide=func(dr,dc):
		var nr:=r+dr; var nc:=c+dc
		while nr>=0 and nr<8 and nc>=0 and nc<8:
			if board[nr][nc]!="":
				if board[nr][nc].substr(0,1)!=col: res.append(Vector2i(nc,nr))
				break
			res.append(Vector2i(nc,nr)); nr+=dr; nc+=dc
	if type=="P":
		var d:=(-1 if col=="w" else 1); var start:=(6 if col=="w" else 1)
		if r+d>=0 and r+d<8 and board[r+d][c]=="":
			res.append(Vector2i(c,r+d))
			if r==start and board[r+2*d][c]=="": res.append(Vector2i(c,r+2*d))
		for dc in [-1,1]:
			if c+dc>=0 and c+dc<8 and r+d>=0 and r+d<8:
				if board[r+d][c+dc]!="" and board[r+d][c+dc].substr(0,1)!=col: res.append(Vector2i(c+dc,r+d))
	if type=="N":
		for off in [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]]: add.call(r+off[0],c+off[1])
	if type=="B" or type=="Q":
		for d in [[-1,-1],[-1,1],[1,-1],[1,1]]: slide.call(d[0],d[1])
	if type=="R" or type=="Q":
		for d in [[-1,0],[1,0],[0,-1],[0,1]]: slide.call(d[0],d[1])
	if type=="K":
		for off in [[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]]: add.call(r+off[0],c+off[1])
	return res

func _draw_board() -> void:
	var cv:=_canvas
	for r in range(8):
		for c in range(8):
			var rect:=Rect2(c*CELL,r*CELL,CELL,CELL)
			var base:=LIGHT if (r+c)%2==0 else DARK
			cv.draw_rect(rect, base)
			if sel!=Vector2i(-1,-1) and sel==Vector2i(c,r): cv.draw_rect(rect,SEL_COL)
			if Vector2i(c,r) in moves:
				cv.draw_rect(rect,HINT_COL)
				cv.draw_circle(Vector2(c*CELL+CELL/2,r*CELL+CELL/2), CELL*0.15, Color(ArcadeTheme.C_GREEN,0.7))
			var p: String = board[r][c]
			if p!="":
				var glyph: String = GLYPH.get(p, "?")
				var col:=(Color(0.92,0.92,1.0) if p.substr(0,1)=="w" else Color(0.35,0.35,0.6))
				cv.draw_string(ThemeDB.fallback_font, Vector2(c*CELL+8,r*CELL+CELL-8), glyph, HORIZONTAL_ALIGNMENT_LEFT, -1, int(CELL-10), col)
	cv.draw_rect(Rect2(0,0,8*CELL,8*CELL), ArcadeTheme.C_BORDER, false, 1.5)
