extends BaseGame
# ─────────────────────────────────────
#  Mahjong.gd  —  Mahjong Solitaire
# ─────────────────────────────────────

const TW := 44.0; const TH := 58.0
const OX := 3.0;  const OY := 3.0

# All available tile symbols (pairs)
const TILE_SYMS := [
	"🀇","🀈","🀉","🀊","🀋","🀌","🀍","🀎","🀏",
	"🀙","🀚","🀛","🀜","🀝","🀞","🀟","🀠","🀡",
	"🀐","🀑","🀒","🀓","🀔","🀕","🀖","🀗","🀘",
	"🀀","🀁","🀂","🀃"
]

var tiles: Array = []    # {col, row, layer, sym, removed, id}
var selected_id: int = -1
var pairs_removed: int = 0
var _canvas: Control
var _rem_lbl: Label; var _pairs_lbl: Label
var _canvas_offset: Vector2

func _game_init() -> void:
	game_title = "MAHJONG"
	accent_color = ArcadeTheme.C_PURPLE

func _game_ready() -> void:

	var vbox := VBoxContainer.new(); vbox.add_theme_constant_override("separation",10)
	_content.add_child(vbox)
	var hud := make_hud_row([
		{"label":"RESTANTES","id":"rem","color":ArcadeTheme.C_PURPLE,"value":"-"},
		{"label":"PARES","id":"pairs","color":ArcadeTheme.C_GREEN,"value":"0"},
	])
	vbox.add_child(hud)
	_rem_lbl=hud.get_node("rem"); _pairs_lbl=hud.get_node("pairs")

	var scroll := ScrollContainer.new(); scroll.size_flags_vertical=Control.SIZE_EXPAND_FILL
	_canvas = Control.new()
	_canvas.draw.connect(_draw_board)
	_canvas.gui_input.connect(_on_input)
	_canvas.mouse_filter=Control.MOUSE_FILTER_STOP
	scroll.add_child(_canvas); vbox.add_child(scroll)

	var btn := make_gbtn("NOVO JOGO",ArcadeTheme.C_PURPLE); btn.pressed.connect(start_game); vbox.add_child(btn)
	var hint := Label.new(); hint.text="Clique em 2 pedras IGUAIS e LIVRES para remover"
	hint.add_theme_font_size_override("font_size",11); hint.add_theme_color_override("font_color",ArcadeTheme.C_DIM)
	vbox.add_child(hint); start_game()

func _build_layout() -> Array:
	var pos := []
	# Layer 0: wide base
	for r in range(4):
		var cols_def := [range(1,9), range(0,10), range(0,10), range(1,9)]
		for c in cols_def[r]: pos.append([c, r+1, 0])
	# Layer 1
	for r in range(4):
		var cols_def := [range(1,8), range(2,7), range(2,7), range(1,8)]
		for c in cols_def[r]: pos.append([c, r+1, 1])
	# Layer 2
	for r in range(4):
		var cols_def := [range(2,7), range(3,6), range(3,6), range(2,7)]
		for c in cols_def[r]: pos.append([c, r+1, 2])
	# Layer 3
	for r in range(3):
		var cols_def := [range(3,7), range(4,6), []]
		for c in cols_def[r]: pos.append([c, r+1, 3])
	return pos

func start_game() -> void:
	var layout := _build_layout()
	var n := layout.size()
	# Fill with pairs (repeat symbols as needed)
	var syms := []
	while syms.size() < n:
		for s in TILE_SYMS: syms.append(s); syms.append(s)
	syms = syms.slice(0, n); syms.shuffle()
	tiles = []
	for i in layout.size():
		var p: Array = layout[i]
		tiles.append({"col":p[0],"row":p[1],"layer":p[2],"sym":syms[i],"removed":false,"id":i})
	selected_id=-1; pairs_removed=0
	_rem_lbl.text=str(tiles.size()); _pairs_lbl.text="0"; set_status("")
	# Size canvas
	var max_col := tiles.map(func(t): return t["col"]).max()
	var max_row := tiles.map(func(t): return t["row"]).max()
	_canvas.custom_minimum_size=Vector2((max_col+2)*(TW+1)+OX*4+20, (max_row+2)*(TH-10)+OY*4+30)
	_canvas.queue_redraw()

func _is_free(t:Dictionary) -> bool:
	# Not blocked above
	var above := tiles.any(func(o): return not o["removed"] and o!=t and o["layer"]==t["layer"]+1 and abs(o["col"]-t["col"])<=1 and abs(o["row"]-t["row"])<=1)
	if above: return false
	# Not sandwiched left-right
	var has_l := tiles.any(func(o): return not o["removed"] and o!=t and o["layer"]==t["layer"] and o["col"]==t["col"]-1 and abs(o["row"]-t["row"])<1)
	var has_r := tiles.any(func(o): return not o["removed"] and o!=t and o["layer"]==t["layer"] and o["col"]==t["col"]+1 and abs(o["row"]-t["row"])<1)
	return not (has_l and has_r)

func _tile_at(pos:Vector2) -> int:
	# Check tiles from top layer down
	var sorted := tiles.filter(func(t): return not t["removed"])
	sorted.sort_custom(func(a,b): return a["layer"]>b["layer"] or (a["layer"]==b["layer"] and a["row"]>b["row"]))
	for t in sorted:
		var tx: float = (t["col"] as float)*(TW+1)+(t["layer"] as float)*OX+10
		var ty: float = (t["row"] as float)*(TH-10)+(t["layer"] as float)*OY+10
		if pos.x>=tx and pos.x<=tx+TW and pos.y>=ty and pos.y<=ty+TH:
			return t["id"]
	return -1

func _on_input(event:InputEvent) -> void:
	if not (event is InputEventMouseButton and event.pressed and event.button_index==1): return
	var idx := _tile_at(event.position)
	if idx < 0: return
	var t: Dictionary = tiles[idx]
	if t["removed"] or not _is_free(t): return
	if selected_id < 0:
		selected_id=idx; _canvas.queue_redraw(); return
	if selected_id==idx: selected_id=-1; _canvas.queue_redraw(); return
	var other: Dictionary = tiles[selected_id]
	if other["sym"]==t["sym"]:
		t["removed"]=true; other["removed"]=true; pairs_removed+=1; selected_id=-1
		var rem := tiles.filter(func(x): return not x["removed"]).size()
		_rem_lbl.text=str(rem); _pairs_lbl.text=str(pairs_removed)
		if rem==0: set_status("🏆 VOCÊ VENCEU!", ArcadeTheme.C_GREEN)
		else:
			var free_tiles := tiles.filter(func(x): return not x["removed"] and _is_free(x))
			var has_move := false
			for a in free_tiles:
				for b in free_tiles:
					if a!=b and a["sym"]==b["sym"]: has_move=true; break
				if has_move: break
			if not has_move: set_status("😔 SEM MOVIMENTOS! Tente novo jogo.", ArcadeTheme.C_RED)
	else: selected_id=idx
	_canvas.queue_redraw()

func _draw_board() -> void:
	var cv := _canvas
	var sorted := tiles.filter(func(t): return not t["removed"])
	sorted.sort_custom(func(a,b): return a["layer"]<b["layer"] or (a["layer"]==b["layer"] and a["row"]<b["row"]))
	for t in sorted:
		var tx: float = (t["col"] as float)*(TW+1)+(t["layer"] as float)*OX+10
		var ty: float = (t["row"] as float)*(TH-10)+(t["layer"] as float)*OY+10
		var rect:=Rect2(tx,ty,TW,TH)
		var is_free:=_is_free(t)
		var is_sel: bool = t["id"]==selected_id
		# Shadow
		cv.draw_rect(Rect2(tx+3,ty+3,TW,TH), Color(0,0,0,0.5))
		# Tile bg
		var bg:=Color(0.12,0.06,0.20) if is_sel else (Color(0.10,0.10,0.22) if is_free else Color(0.06,0.06,0.14))
		cv.draw_rect(rect, bg)
		# Border
		var border:=ArcadeTheme.C_YELLOW if is_sel else (Color(0.5,0.3,1.0,0.5) if is_free else Color(0.2,0.2,0.35,0.4))
		cv.draw_rect(rect, border, false, 1.5)
		# Symbol
		if is_free:
			cv.draw_string(ThemeDB.fallback_font, Vector2(tx+4,ty+TH-8), t["sym"], HORIZONTAL_ALIGNMENT_LEFT,-1,int(TH-12),ArcadeTheme.C_TEXT)
		else:
			cv.draw_string(ThemeDB.fallback_font, Vector2(tx+4,ty+TH-8), t["sym"], HORIZONTAL_ALIGNMENT_LEFT,-1,int(TH-12),Color(0.3,0.3,0.4))
