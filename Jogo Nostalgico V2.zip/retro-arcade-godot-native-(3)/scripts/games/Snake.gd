extends BaseGame
# ─────────────────────────────────────
#  Snake.gd
# ─────────────────────────────────────

const CELL := 24
const COLS := 24
const ROWS := 20

var snake: Array = []
var direction: Vector2i = Vector2i(1, 0)
var next_dir: Vector2i = Vector2i(1, 0)
var food: Vector2i = Vector2i(0, 0)
var score: int = 0
var hi_score: int = 0
var running: bool = false
var step_timer: float = 0.0
var speed: float = 0.12
var _canvas: Control
var _score_lbl: Label
var _hi_lbl: Label

func _game_init() -> void:
	game_title = "SNAKE"
	accent_color = ArcadeTheme.C_GREEN

func _game_ready() -> void:

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 12)
	_content.add_child(vbox)

	var hud := make_hud_row([
		{"label":"SCORE","id":"score","color":ArcadeTheme.C_GREEN,"value":"0"},
		{"label":"RECORDE","id":"hi","color":ArcadeTheme.C_YELLOW,"value":"0"},
	])
	vbox.add_child(hud)
	_score_lbl = hud.get_node("score")
	_hi_lbl    = hud.get_node("hi")

	_canvas = Control.new()
	_canvas.custom_minimum_size = Vector2(COLS*CELL, ROWS*CELL)
	_canvas.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	_canvas.draw.connect(_draw_game)
	vbox.add_child(_canvas)

	var hbox := HBoxContainer.new()
	hbox.add_theme_constant_override("separation", 10)
	var btn := make_gbtn("NOVO JOGO", ArcadeTheme.C_GREEN)
	btn.pressed.connect(start_game)
	hbox.add_child(btn)
	vbox.add_child(hbox)

	var hint := Label.new()
	hint.text = "← → ↑ ↓  MOVER"
	hint.add_theme_font_size_override("font_size", 11)
	hint.add_theme_color_override("font_color", ArcadeTheme.C_DIM)
	vbox.add_child(hint)

	start_game()

func start_game() -> void:
	snake = [Vector2i(12,10), Vector2i(11,10), Vector2i(10,10)]
	direction = Vector2i(1, 0); next_dir = Vector2i(1, 0)
	score = 0; running = true; step_timer = 0.0
	_score_lbl.text = "0"; set_status("")
	_place_food()
	_canvas.queue_redraw()

func _place_food() -> void:
	var tries := 0
	while tries < 200:
		var fx := randi_range(0, COLS-1)
		var fy := randi_range(0, ROWS-1)
		var pos := Vector2i(fx, fy)
		if pos not in snake:
			food = pos; return
		tries += 1

func _process(delta: float) -> void:
	if not running: return
	step_timer += delta
	if step_timer >= speed:
		step_timer = 0.0
		_step()

func _input(event: InputEvent) -> void:
	if not visible or not running: return
	if event is InputEventKey and event.pressed:
		match event.keycode:
			KEY_UP:    if direction.y == 0: next_dir = Vector2i(0,-1)
			KEY_DOWN:  if direction.y == 0: next_dir = Vector2i(0, 1)
			KEY_LEFT:  if direction.x == 0: next_dir = Vector2i(-1,0)
			KEY_RIGHT: if direction.x == 0: next_dir = Vector2i( 1,0)

func _step() -> void:
	direction = next_dir
	var head: Vector2i = snake[0] + direction
	if head.x < 0 or head.x >= COLS or head.y < 0 or head.y >= ROWS or head in snake:
		running = false
		if score > hi_score: hi_score = score; _hi_lbl.text = str(hi_score)
		set_status("💀 FIM DE JOGO!  SCORE: " + str(score), ArcadeTheme.C_RED)
		return
	snake.push_front(head)
	if head == food:
		score += 10; _score_lbl.text = str(score)
		speed = maxf(0.06, speed - 0.002)
		_place_food()
	else:
		snake.pop_back()
	_canvas.queue_redraw()

func _draw_game() -> void:
	var cv := _canvas
	cv.draw_rect(Rect2(0,0,COLS*CELL,ROWS*CELL), ArcadeTheme.C_BG)
	for r in range(ROWS):
		for c in range(COLS):
			cv.draw_rect(Rect2(c*CELL+1,r*CELL+1,CELL-2,CELL-2), Color(0.06,0.06,0.12))
	# Food
	var fc := food
	cv.draw_circle(Vector2(fc.x*CELL+CELL/2.0, fc.y*CELL+CELL/2.0), CELL/2.0-2, ArcadeTheme.C_RED)
	# Snake
	for i in snake.size():
		var s: Vector2i = snake[i]
		var t := 1.0 - float(i)/snake.size() * 0.5
		var col := ArcadeTheme.C_GREEN if i == 0 else Color(0, t*0.85, t*0.55)
		cv.draw_rect(Rect2(s.x*CELL+1, s.y*CELL+1, CELL-2, CELL-2), col)
	cv.draw_rect(Rect2(0,0,COLS*CELL,ROWS*CELL), ArcadeTheme.C_BORDER, false, 1.5)
