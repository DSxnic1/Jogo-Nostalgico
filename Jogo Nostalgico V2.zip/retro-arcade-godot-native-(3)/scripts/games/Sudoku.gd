extends BaseGame
# ─────────────────────────────────────
#  Sudoku.gd
# ─────────────────────────────────────

const CELL := 52.0

var solution: Array = []
var puzzle: Array = []
var given: Array = []    # which cells are pre-filled
var sel: Vector2i = Vector2i(-1,-1)
var errors: int = 0
var _canvas: Control
var _err_lbl: Label; var _diff_lbl: Label

func _game_init() -> void:
	game_title = "SUDOKU"
	accent_color = ArcadeTheme.C_BLUE

func _game_ready() -> void:

	var vbox := VBoxContainer.new(); vbox.add_theme_constant_override("separation",10)
	_content.add_child(vbox)
	var hud := make_hud_row([
		{"label":"DIFICULDADE","id":"diff","color":ArcadeTheme.C_BLUE,"value":"MÉDIO"},
		{"label":"ERROS","id":"err","color":ArcadeTheme.C_RED,"value":"0"},
	])
	vbox.add_child(hud)
	_diff_lbl=hud.get_node("diff"); _err_lbl=hud.get_node("err")

	var main_hbox := HBoxContainer.new(); main_hbox.add_theme_constant_override("separation",16)
	vbox.add_child(main_hbox)

	_canvas = Control.new()
	_canvas.custom_minimum_size = Vector2(9*CELL, 9*CELL)
	_canvas.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	_canvas.draw.connect(_draw_board)
	_canvas.gui_input.connect(_on_canvas_input)
	_canvas.mouse_filter = Control.MOUSE_FILTER_STOP
	main_hbox.add_child(_canvas)

	# Right side: numpad + diff buttons
	var side := VBoxContainer.new(); side.add_theme_constant_override("separation",8)
	main_hbox.add_child(side)
	var np_lbl := Label.new(); np_lbl.text = "NÚMERO"
	np_lbl.add_theme_font_size_override("font_size",10); np_lbl.add_theme_color_override("font_color",ArcadeTheme.C_DIM)
	side.add_child(np_lbl)
	var grid := GridContainer.new(); grid.columns=3; grid.add_theme_constant_override("h_separation",6); grid.add_theme_constant_override("v_separation",6)
	for n in range(1,10):
		var b := make_gbtn(str(n), ArcadeTheme.C_BLUE); b.custom_minimum_size=Vector2(44,44)
		b.pressed.connect(func(): _place(n)); grid.add_child(b)
	side.add_child(grid)
	var era := make_gbtn("✕ APAGAR", ArcadeTheme.C_RED); era.pressed.connect(func(): _place(0)); side.add_child(era)
	var sep := HSeparator.new(); side.add_child(sep)
	var dl := Label.new(); dl.text = "DIFICULDADE"
	dl.add_theme_font_size_override("font_size",10); dl.add_theme_color_override("font_color",ArcadeTheme.C_DIM)
	side.add_child(dl)
	for d in [["FÁCIL",35],["MÉDIO",47],["DIFÍCIL",55]]:
		var b := make_gbtn(d[0], ArcadeTheme.C_BLUE)
		var rm:int=d[1]; var dn:String=d[0]
		b.pressed.connect(func(): _new_game(rm, dn)); side.add_child(b)

	_new_game(47, "MÉDIO")

func _new_game(remove_count:int, diff_name:String) -> void:
	_diff_lbl.text=diff_name; errors=0; _err_lbl.text="0"; set_status(""); sel=Vector2i(-1,-1)
	_generate(remove_count); _canvas.queue_redraw()

func _generate(remove_count:int) -> void:
	solution=Array(); puzzle=Array(); given=Array()
	for _r in range(9): solution.append([]); puzzle.append([]); given.append([])
	for r in range(9):
		for _c in range(9): solution[r].append(0); puzzle[r].append(0); given[r].append(true)
	_solve(solution)
	for r in range(9):
		for c in range(9): puzzle[r][c]=solution[r][c]
	var removed:=0
	while removed<remove_count:
		var r:=randi()%9; var c:=randi()%9
		if puzzle[r][c]!=0: puzzle[r][c]=0; given[r][c]=false; removed+=1

func _valid(b:Array,r:int,c:int,n:int) -> bool:
	for i in range(9):
		if b[r][i]==n or b[i][c]==n: return false
	var br:=(r/3)*3; var bc:=(c/3)*3
	for dr in range(3):
		for dc in range(3):
			if b[br+dr][bc+dc]==n: return false
	return true

func _solve(b:Array) -> bool:
	for r in range(9):
		for c in range(9):
			if b[r][c]==0:
				var nums:=range(1,10); nums.shuffle()
				for n in nums:
					if _valid(b,r,c,n):
						b[r][c]=n
						if _solve(b): return true
						b[r][c]=0
				return false
	return true

func _on_canvas_input(event:InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed and event.button_index==1:
		var c:=int(event.position.x/CELL); var r:=int(event.position.y/CELL)
		if r>=0 and r<9 and c>=0 and c<9 and not given[r][c]:
			sel=Vector2i(c,r); _canvas.queue_redraw()

func _input(event:InputEvent) -> void:
	if not visible or sel==Vector2i(-1,-1): return
	if event is InputEventKey and event.pressed:
		if event.keycode>=KEY_1 and event.keycode<=KEY_9: _place(event.keycode-KEY_0)
		if event.keycode==KEY_BACKSPACE or event.keycode==KEY_DELETE: _place(0)

func _place(n:int) -> void:
	if sel==Vector2i(-1,-1): return
	var r:=sel.y; var c:=sel.x
	if given[r][c]: return
	puzzle[r][c]=n
	if n!=0 and n!=solution[r][c]:
		errors+=1; _err_lbl.text=str(errors)
	var done:=true
	for row in range(9):
		for col in range(9):
			if puzzle[row][col]!=solution[row][col]: done=false; break
	if done: set_status("🏆 SUDOKU COMPLETO!", ArcadeTheme.C_GREEN)
	_canvas.queue_redraw()

func _draw_board() -> void:
	var cv:=_canvas
	var board_size:=9*CELL
	cv.draw_rect(Rect2(0,0,board_size,board_size), ArcadeTheme.C_PANEL2)
	for r in range(9):
		for c in range(9):
			var rx:=c*CELL; var ry:=r*CELL
			var rect:=Rect2(rx+1,ry+1,CELL-2,CELL-2)
			var bg:=ArcadeTheme.C_PANEL2
			if sel!=Vector2i(-1,-1):
				if sel==Vector2i(c,r): bg=Color(0,0.2,0.35)
				elif sel.x==c or sel.y==r or (c/3)==(sel.x/3) and (r/3)==(sel.y/3): bg=Color(0,0.1,0.18)
			cv.draw_rect(rect,bg)
			var v: int = puzzle[r][c]
			if v!=0:
				var col:=ArcadeTheme.C_BLUE if given[r][c] else (ArcadeTheme.C_GREEN if v==solution[r][c] else ArcadeTheme.C_RED)
				cv.draw_string(ThemeDB.fallback_font, Vector2(rx+CELL/2-10,ry+CELL-12), str(v), HORIZONTAL_ALIGNMENT_LEFT,-1,int(CELL-12),col)
			# Grid lines
			var lw:=1.0
			if (c+1)%3==0 and c<8: lw=2.5
			if c<8: cv.draw_rect(Rect2(rx+CELL-lw,ry,lw,CELL),ArcadeTheme.C_BORDER if lw<2 else ArcadeTheme.C_BLUE)
			lw=1.0
			if (r+1)%3==0 and r<8: lw=2.5
			if r<8: cv.draw_rect(Rect2(rx,ry+CELL-lw,CELL,lw),ArcadeTheme.C_BORDER if lw<2 else ArcadeTheme.C_BLUE)
	cv.draw_rect(Rect2(0,0,board_size,board_size),ArcadeTheme.C_BLUE,false,2)
