extends Control
# ─────────────────────────────────────────────────────────────
#  Hub.gd  —  Game selection screen
#  All 18 games defined here with category, icon, color, scene.
# ─────────────────────────────────────────────────────────────

const GAMES := [
	# ── ARCADE ──────────────────────────────────────────
	{ "id":"tetris",        "name":"TETRIS",           "icon":"🟩", "cat":"Arcade",     "color": ArcadeTheme.C_GREEN,  "desc":"Encaixe as peças!" },
	{ "id":"snake",         "name":"SNAKE",            "icon":"🐍", "cat":"Arcade",     "color": ArcadeTheme.C_RED,    "desc":"Coma e cresça" },
	{ "id":"pong",          "name":"PONG",             "icon":"🏓", "cat":"Arcade",     "color": ArcadeTheme.C_BLUE,   "desc":"vs CPU" },
	{ "id":"breakout",      "name":"BREAKOUT",         "icon":"🧱", "cat":"Arcade",     "color": ArcadeTheme.C_ORANGE, "desc":"Quebre os tijolos" },
	{ "id":"spaceinvaders", "name":"SPACE INVADERS",   "icon":"👾", "cat":"Arcade",     "color": ArcadeTheme.C_GREEN,  "desc":"Defenda a Terra!" },
	{ "id":"simon",         "name":"SIMON SAYS",       "icon":"🔵", "cat":"Arcade",     "color": ArcadeTheme.C_PURPLE, "desc":"Repita a sequência" },
	# ── ESTRATÉGIA ──────────────────────────────────────
	{ "id":"chess",         "name":"XADREZ",           "icon":"♟",  "cat":"Estratégia", "color": ArcadeTheme.C_PURPLE, "desc":"Rei vs Rei" },
	{ "id":"connect4",      "name":"CONNECT 4",        "icon":"🔴", "cat":"Estratégia", "color": ArcadeTheme.C_BLUE,   "desc":"4 em linha vence" },
	{ "id":"minesweeper",   "name":"CAMPO MINADO",     "icon":"💣", "cat":"Estratégia", "color": ArcadeTheme.C_ORANGE, "desc":"Não pise nas minas!" },
	{ "id":"mahjong",       "name":"MAHJONG",          "icon":"🀄", "cat":"Estratégia", "color": ArcadeTheme.C_PURPLE, "desc":"Combine as pedras" },
	# ── CARTAS ──────────────────────────────────────────
	{ "id":"solitaire",     "name":"PACIÊNCIA",        "icon":"🂡", "cat":"Cartas",     "color": ArcadeTheme.C_RED,    "desc":"Klondike clássico" },
	{ "id":"memory",        "name":"MEMÓRIA",          "icon":"🎴", "cat":"Cartas",     "color": ArcadeTheme.C_YELLOW, "desc":"Encontre os pares" },
	{ "id":"blackjack",     "name":"BLACKJACK",        "icon":"🃏", "cat":"Cartas",     "color": ArcadeTheme.C_GREEN,  "desc":"Chegue ao 21!" },
	{ "id":"war",           "name":"GUERRA",           "icon":"⚔",  "cat":"Cartas",     "color": ArcadeTheme.C_BLUE,   "desc":"Maior carta vence" },
	{ "id":"videopoker",    "name":"VIDEO POKER",      "icon":"🎰", "cat":"Cartas",     "color": ArcadeTheme.C_PURPLE, "desc":"Jacks or Better" },
	# ── PALAVRAS ────────────────────────────────────────
	{ "id":"wordsearch",    "name":"CAÇA PALAVRAS",    "icon":"🔍", "cat":"Palavras",   "color": ArcadeTheme.C_GREEN,  "desc":"Encontre as palavras" },
	# ── NÚMEROS ─────────────────────────────────────────
	{ "id":"sudoku",        "name":"SUDOKU",           "icon":"🔢", "cat":"Números",    "color": ArcadeTheme.C_BLUE,   "desc":"Lógica numérica" },
]

const SCENE_MAP := {
	"tetris":        "res://scenes/games/Tetris.tscn",
	"snake":         "res://scenes/games/Snake.tscn",
	"pong":          "res://scenes/games/Pong.tscn",
	"breakout":      "res://scenes/games/Breakout.tscn",
	"spaceinvaders": "res://scenes/games/SpaceInvaders.tscn",
	"simon":         "res://scenes/games/Simon.tscn",
	"chess":         "res://scenes/games/Chess.tscn",
	"connect4":      "res://scenes/games/Connect4.tscn",
	"minesweeper":   "res://scenes/games/Minesweeper.tscn",
	"mahjong":       "res://scenes/games/Mahjong.tscn",
	"solitaire":     "res://scenes/games/Solitaire.tscn",
	"memory":        "res://scenes/games/Memory.tscn",
	"blackjack":     "res://scenes/games/Blackjack.tscn",
	"war":           "res://scenes/games/War.tscn",
	"videopoker":    "res://scenes/games/VideoPoker.tscn",
	"wordsearch":    "res://scenes/games/WordSearch.tscn",
	"sudoku":        "res://scenes/games/Sudoku.tscn",
}

const CATEGORIES := ["Arcade", "Estratégia", "Cartas", "Palavras", "Números"]
const CAT_ICONS  := { "Arcade":"🕹️", "Estratégia":"♟", "Cartas":"🃏", "Palavras":"📖", "Números":"🔢" }

var _coin_msgs := ["▶ INSIRA UMA MOEDA ◀","▶ 17 JOGOS CLÁSSICOS ◀","▶ PRESSIONE START ◀","▶ ESCOLHA SEU JOGO ◀"]
var _coin_idx  := 0
var _coin_label: Label

func _ready() -> void:
	_build_ui()
	var t := Timer.new(); add_child(t)
	t.wait_time = 2.0; t.autostart = true
	t.timeout.connect(func():
		_coin_idx = (_coin_idx + 1) % _coin_msgs.size()
		if _coin_label: _coin_label.text = _coin_msgs[_coin_idx]
	)

func _build_ui() -> void:
	# Root background
	var bg := ColorRect.new()
	bg.color = ArcadeTheme.C_BG
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)

	# Main scroll + vbox
	var scroll := ScrollContainer.new()
	scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(scroll)

	var root_vbox := VBoxContainer.new()
	root_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root_vbox.add_theme_constant_override("separation", 0)
	scroll.add_child(root_vbox)

	# ── Header ────────────────────────────────────
	var header := _make_header()
	root_vbox.add_child(header)

	# ── Categories ────────────────────────────────
	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 8)
	var margins := MarginContainer.new()
	for side in ["left","right","top","bottom"]:
		margins.add_theme_constant_override("margin_"+side, 24 if side in ["left","right"] else 12)
	margins.add_child(content)
	root_vbox.add_child(margins)

	for cat in CATEGORIES:
		var games_in_cat := GAMES.filter(func(g): return g["cat"] == cat)
		if games_in_cat.is_empty(): continue
		content.add_child(_make_category_section(cat, games_in_cat))

func _make_header() -> Control:
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 6)

	var bg := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.03, 0.03, 0.08)
	sb.border_color = ArcadeTheme.C_GREEN
	sb.border_width_bottom = 1
	bg.add_theme_stylebox_override("panel", sb)

	var inner := VBoxContainer.new()
	inner.add_theme_constant_override("separation", 6)
	var pad := MarginContainer.new()
	for side in ["left","right","top","bottom"]:
		pad.add_theme_constant_override("margin_"+side, 20)
	pad.add_child(inner)
	bg.add_child(pad)

	var title := Label.new()
	title.text = "RETRO ARCADE"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 42)
	title.add_theme_color_override("font_color", ArcadeTheme.C_GREEN)
	inner.add_child(title)

	var sub := Label.new()
	sub.text = "▸ 17 JOGOS CLÁSSICOS — 5 CATEGORIAS ◂"
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub.add_theme_font_size_override("font_size", 12)
	sub.add_theme_color_override("font_color", ArcadeTheme.C_DIM)
	inner.add_child(sub)

	_coin_label = Label.new()
	_coin_label.text = _coin_msgs[0]
	_coin_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_coin_label.add_theme_font_size_override("font_size", 11)
	_coin_label.add_theme_color_override("font_color", ArcadeTheme.C_YELLOW)
	inner.add_child(_coin_label)

	vbox.add_child(bg)
	return vbox

func _make_category_section(cat: String, games: Array) -> Control:
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)

	# Category header
	var hbox := HBoxContainer.new()
	hbox.add_theme_constant_override("separation", 10)
	var accent: Color = ArcadeTheme.CAT_COLOR.get(cat, ArcadeTheme.C_TEXT)

	var icon_lbl := Label.new()
	icon_lbl.text = CAT_ICONS.get(cat, "●")
	icon_lbl.add_theme_font_size_override("font_size", 18)
	hbox.add_child(icon_lbl)

	var cat_lbl := Label.new()
	cat_lbl.text = cat.to_upper()
	cat_lbl.add_theme_font_size_override("font_size", 11)
	cat_lbl.add_theme_color_override("font_color", accent)
	hbox.add_child(cat_lbl)

	var sep := HSeparator.new()
	sep.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var sep_style := StyleBoxFlat.new()
	sep_style.bg_color = Color(accent.r, accent.g, accent.b, 0.25)
	sep_style.content_margin_top = 1
	sep.add_theme_stylebox_override("separator", sep_style)
	hbox.add_child(sep)

	var count_lbl := Label.new()
	count_lbl.text = str(games.size()) + " JOGOS"
	count_lbl.add_theme_font_size_override("font_size", 10)
	count_lbl.add_theme_color_override("font_color", ArcadeTheme.C_DIM)
	hbox.add_child(count_lbl)

	vbox.add_child(hbox)

	# Game cards grid
	var grid := HFlowContainer.new()
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 12)
	for g in games:
		grid.add_child(_make_game_card(g))
	vbox.add_child(grid)

	return vbox

func _make_game_card(game: Dictionary) -> Control:
	var accent: Color = game["color"]

	var btn := Button.new()
	btn.custom_minimum_size = Vector2(165, 120)
	btn.focus_mode = Control.FOCUS_ALL
	btn.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND

	var normal := ArcadeTheme.panel_style(ArcadeTheme.C_PANEL, ArcadeTheme.C_BORDER, 8)
	var hover  := ArcadeTheme.panel_style(
		Color(accent.r*.07, accent.g*.07, accent.b*.07),
		accent, 8)
	btn.add_theme_stylebox_override("normal",  normal)
	btn.add_theme_stylebox_override("hover",   hover)
	btn.add_theme_stylebox_override("pressed", hover)
	btn.add_theme_stylebox_override("focus",   hover)

	# Build interior via a VBoxContainer drawn inside button
	var vbox := VBoxContainer.new()
	vbox.alignment = BoxContainer.ALIGNMENT_CENTER
	vbox.add_theme_constant_override("separation", 8)
	vbox.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	vbox.mouse_filter = Control.MOUSE_FILTER_IGNORE
	btn.add_child(vbox)

	var icon := Label.new()
	icon.text = game["icon"]
	icon.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	icon.add_theme_font_size_override("font_size", 30)
	icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vbox.add_child(icon)

	var name_lbl := Label.new()
	name_lbl.text = game["name"]
	name_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	name_lbl.add_theme_font_size_override("font_size", 9)
	name_lbl.add_theme_color_override("font_color", accent)
	name_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	name_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vbox.add_child(name_lbl)

	var desc_lbl := Label.new()
	desc_lbl.text = game["desc"]
	desc_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	desc_lbl.add_theme_font_size_override("font_size", 10)
	desc_lbl.add_theme_color_override("font_color", ArcadeTheme.C_DIM)
	desc_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vbox.add_child(desc_lbl)

	var gid: String = game["id"]
	btn.pressed.connect(func(): _launch(gid))
	return btn

func _launch(game_id: String) -> void:
	var path: String = SCENE_MAP.get(game_id, "")
	if path.is_empty():
		return
	var packed = load(path)
	if packed == null:
		push_error("Scene not found: " + path)
		return
	var scene = packed.instantiate()
	get_tree().root.add_child(scene)
	hide()
	scene.tree_exiting.connect(func(): show())
