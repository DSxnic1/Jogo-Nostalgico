extends Node
# ─────────────────────────────────────
#  ArcadeTheme.gd  (AutoLoad as "Theme")
#  Global palette & style factory
# ─────────────────────────────────────

const C_BG      := Color(0.024, 0.024, 0.059)
const C_PANEL   := Color(0.051, 0.051, 0.110)
const C_PANEL2  := Color(0.067, 0.067, 0.157)
const C_BORDER  := Color(0.110, 0.110, 0.220)
const C_DIM     := Color(0.250, 0.250, 0.400)
const C_TEXT    := Color(0.820, 0.820, 0.945)

const C_GREEN   := Color(0.000, 1.000, 0.667)   # #00ffaa
const C_BLUE    := Color(0.000, 0.810, 1.000)   # #00cfff
const C_PURPLE  := Color(0.749, 0.373, 1.000)   # #bf5fff
const C_YELLOW  := Color(1.000, 0.847, 0.302)   # #ffd84d
const C_RED     := Color(1.000, 0.200, 0.400)   # #ff3366
const C_ORANGE  := Color(1.000, 0.467, 0.200)   # #ff7733

# Category accent colours
const CAT_COLOR := {
	"Arcade":     C_RED,
	"Estratégia": C_PURPLE,
	"Cartas":     C_YELLOW,
	"Palavras":   C_GREEN,
	"Números":    C_BLUE,
}

# ── Style factories ─────────────────────────────

func panel_style(bg: Color = C_PANEL, border: Color = C_BORDER, radius: int = 8) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(1)
	s.set_corner_radius_all(radius)
	return s

func button_style(border_color: Color = C_BORDER, bg: Color = C_PANEL2) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border_color
	s.set_border_width_all(1)
	s.set_corner_radius_all(4)
	s.content_margin_left = 16
	s.content_margin_right = 16
	s.content_margin_top = 8
	s.content_margin_bottom = 8
	return s

func make_label(text: String, size: int = 14, color: Color = C_TEXT) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	return l

func make_button(text: String, accent: Color = C_GREEN) -> Button:
	var b := Button.new()
	b.text = text
	b.add_theme_color_override("font_color", C_TEXT)
	b.add_theme_font_size_override("font_size", 14)
	var normal := button_style(C_BORDER, C_PANEL2)
	var hover  := button_style(accent, Color(accent.r*.12, accent.g*.12, accent.b*.12))
	var press  := button_style(accent, Color(accent.r*.20, accent.g*.20, accent.b*.20))
	b.add_theme_stylebox_override("normal", normal)
	b.add_theme_stylebox_override("hover",  hover)
	b.add_theme_stylebox_override("pressed", press)
	b.add_theme_stylebox_override("focus",  hover)
	b.add_theme_color_override("font_hover_color", accent)
	b.add_theme_color_override("font_pressed_color", accent)
	return b
