extends Control
# ─────────────────────────────────────────────
#  BaseGame.gd  —  Base class for all games
#
#  Execution order:
#    1. _ready() calls _game_init() — subclass sets game_title + accent_color ONLY
#    2. _ready() calls _build_frame() — builds topbar/content/statusbar using those values
#    3. _ready() calls _game_ready() — subclass populates _content with game UI
#
#  Subclasses implement _game_init() and _game_ready(). Never override _ready().
# ─────────────────────────────────────────────
class_name BaseGame

var game_title: String = "JOGO"
var accent_color: Color = Color(0, 1, 0.67)  # C_GREEN default

var _status_label: Label
var _content: Control   # add your game UI here in _game_ready()

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_game_init()      # subclass sets title + color
	_build_frame()    # frame uses those values
	_game_ready()     # subclass builds game UI into _content

# ── Override in subclass: set game_title and accent_color ──────
func _game_init() -> void:
	pass

# ── Override in subclass: add UI nodes to _content ────────────
func _game_ready() -> void:
	pass

# ── Build the shared chrome ────────────────────────────────────
func _build_frame() -> void:
	# Background
	var bg := ColorRect.new()
	bg.color = ArcadeTheme.C_BG
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)

	var root_vbox := VBoxContainer.new()
	root_vbox.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root_vbox.add_theme_constant_override("separation", 0)
	add_child(root_vbox)

	# ── Top bar ──────────────────────────────────────────────
	var topbar := PanelContainer.new()
	topbar.custom_minimum_size.y = 52
	var tb_style := StyleBoxFlat.new()
	tb_style.bg_color = Color(0.04, 0.04, 0.10)
	tb_style.border_color = accent_color
	tb_style.border_width_bottom = 1
	topbar.add_theme_stylebox_override("panel", tb_style)

	var tb_hbox := HBoxContainer.new()
	tb_hbox.add_theme_constant_override("separation", 12)
	var tb_pad := MarginContainer.new()
	for side in ["left", "right"]:
		tb_pad.add_theme_constant_override("margin_" + side, 16)
	tb_pad.add_theme_constant_override("margin_top", 8)
	tb_pad.add_theme_constant_override("margin_bottom", 8)
	tb_pad.add_child(tb_hbox)
	topbar.add_child(tb_pad)

	var back_btn := ArcadeTheme.make_button("◀  VOLTAR", ArcadeTheme.C_DIM)
	back_btn.custom_minimum_size.x = 110
	back_btn.pressed.connect(_on_back)
	tb_hbox.add_child(back_btn)

	var title_lbl := Label.new()
	title_lbl.text = game_title
	title_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title_lbl.add_theme_font_size_override("font_size", 22)
	title_lbl.add_theme_color_override("font_color", accent_color)
	tb_hbox.add_child(title_lbl)

	root_vbox.add_child(topbar)

	# ── Content area (subclass adds children here) ────────────
	var content_pad := MarginContainer.new()
	content_pad.size_flags_vertical = Control.SIZE_EXPAND_FILL
	for side in ["left", "right", "top", "bottom"]:
		content_pad.add_theme_constant_override("margin_" + side, 18)
	root_vbox.add_child(content_pad)
	_content = content_pad

	# ── Status bar ────────────────────────────────────────────
	var status_bar := PanelContainer.new()
	status_bar.custom_minimum_size.y = 36
	var sb_style := StyleBoxFlat.new()
	sb_style.bg_color = Color(0.03, 0.03, 0.08)
	sb_style.border_color = ArcadeTheme.C_BORDER
	sb_style.border_width_top = 1
	status_bar.add_theme_stylebox_override("panel", sb_style)

	_status_label = Label.new()
	_status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_status_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_status_label.add_theme_font_size_override("font_size", 13)
	_status_label.add_theme_color_override("font_color", ArcadeTheme.C_YELLOW)
	status_bar.add_child(_status_label)
	root_vbox.add_child(status_bar)

# ── Helpers ───────────────────────────────────────────────────

func set_status(text: String, color: Color = ArcadeTheme.C_YELLOW) -> void:
	if _status_label:
		_status_label.text = text
		_status_label.add_theme_color_override("font_color", color)

func _on_back() -> void:
	queue_free()

func make_hud_row(items: Array) -> HBoxContainer:
	var hbox := HBoxContainer.new()
	hbox.add_theme_constant_override("separation", 10)
	for item in items:
		var panel := PanelContainer.new()
		panel.add_theme_stylebox_override("panel",
			ArcadeTheme.panel_style(ArcadeTheme.C_PANEL2, ArcadeTheme.C_BORDER, 6))
		var vb := VBoxContainer.new()
		vb.add_theme_constant_override("separation", 2)

		var lbl := Label.new()
		lbl.text = item.get("label", "")
		lbl.add_theme_font_size_override("font_size", 10)
		lbl.add_theme_color_override("font_color", ArcadeTheme.C_DIM)
		lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

		var val := Label.new()
		val.name = item.get("id", item.get("label", "val"))
		val.text = item.get("value", "0")
		val.add_theme_font_size_override("font_size", 20)
		var val_color: Color = item.get("color", ArcadeTheme.C_YELLOW)
		val.add_theme_color_override("font_color", val_color)
		val.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

		vb.add_child(lbl)
		vb.add_child(val)
		panel.add_child(vb)
		hbox.add_child(panel)
	return hbox

func make_gbtn(text: String, accent: Color = ArcadeTheme.C_GREEN) -> Button:
	return ArcadeTheme.make_button(text, accent)
