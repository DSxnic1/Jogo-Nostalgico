# 🕹️ RETRO ARCADE — Projeto Godot Nativo

**17 jogos clássicos rodando 100% local dentro do Godot 4. Zero browser, zero internet.**

---

## 📁 Estrutura

```
retro_arcade/
├── project.godot              ← Abra este no Godot
├── scenes/
│   ├── Hub.tscn               ← Tela principal de seleção
│   └── games/
│       ├── Tetris.tscn        ← Cada jogo tem sua cena
│       ├── Snake.tscn
│       └── ... (17 jogos)
├── scripts/
│   ├── ArcadeTheme.gd         ← Paleta neon e helpers de estilo (AutoLoad)
│   ├── BaseGame.gd            ← Classe base para todos os jogos
│   ├── Hub.gd                 ← Lógica do menu principal
│   └── games/
│       ├── Tetris.gd
│       ├── Snake.gd
│       └── ... (17 scripts)
└── themes/
    └── arcade.tres
```

---

## 🚀 Como Abrir

1. Baixe o **Godot 4.2+** em https://godotengine.org/download
2. Abra o Godot → clique **Importar**
3. Navegue até a pasta `retro_arcade/`
4. Selecione `project.godot` → **Importar e Abrir**
5. Pressione **F5** para rodar

> ✅ Funciona 100% offline. Nenhum browser é aberto.

---

## 🎮 Os 17 Jogos

### 🕹️ Arcade Clássico
| Jogo | Controles |
|------|-----------|
| **Tetris** | ← → mover · ↑ girar · ↓ descer · Espaço drop |
| **Snake** | ← → ↑ ↓ mover |
| **Pong** | W/S ou ↑/↓ |
| **Breakout** | ← → ou mouse · Espaço/clique lançar |
| **Space Invaders** | ← → mover · Espaço atirar |
| **Simon Says** | Clique nas cores |

### ♟️ Estratégia
| Jogo | Controles |
|------|-----------|
| **Xadrez** | Clique para selecionar · clique para mover |
| **Connect 4** | Clique na coluna |
| **Campo Minado** | Clique: abrir · Direito: bandeira |
| **Mahjong** | Clique em 2 pedras iguais e livres |

### 🃏 Cartas
| Jogo | Descrição |
|------|-----------|
| **Paciência** | Klondike clássico |
| **Memória** | 8 pares de emojis |
| **Blackjack** | Hit, Stand, Double contra o dealer |
| **Guerra** | Maior carta vence |
| **Video Poker** | Jacks or Better |

### 📖 Palavras
| Jogo | Controles |
|------|-----------|
| **Caça Palavras** | Clique na 1ª e última letra |

### 🔢 Números
| Jogo | Controles |
|------|-----------|
| **Sudoku** | Clique na célula · clique no número |

---

## 🏗️ Arquitetura

Todos os jogos estendem `BaseGame.gd` que fornece:
- Barra superior com botão **◀ VOLTAR**
- Área de conteúdo (`_content`)
- Barra de status (`set_status()`)
- Helpers de HUD (`make_hud_row()`, `make_gbtn()`)
- Paleta neon via `ArcadeTheme` (autoload)

Cada jogo implementa apenas `_game_ready()` com sua lógica específica.

---

## 🎨 Design System

`ArcadeTheme.gd` define a paleta completa:

| Variável | Cor | Uso |
|----------|-----|-----|
| `C_GREEN` | #00ffaa | Arcade, confirmação |
| `C_BLUE`  | #00cfff | Estratégia, info |
| `C_PURPLE`| #bf5fff | Mahjong, Simon |
| `C_YELLOW`| #ffd84d | Cartas, destaque |
| `C_RED`   | #ff3366 | Perigo, Arcade |
| `C_ORANGE`| #ff7733 | Breakout, minas |

---

*Desenvolvido com ❤️ — 100% GDScript, 100% offline*
