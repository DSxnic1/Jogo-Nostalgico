extends Area2D

func _input_event(_viewport, event, _shape_idx):
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		comprar_carta()

func comprar_carta():
	# get_tree() deve ser acessível se o nó estiver na cena ativa
	if not is_inside_tree(): 
		return
		
	var mesa = get_tree().current_scene
	if not mesa.has_node("MonteDescarte"):
		return
		
	var descarte = mesa.get_node("MonteDescarte")
	
	# Filtra apenas filhos que são cartas (possuem o método 'virar')
	# Isso evita tratar o CollisionShape2D como carta
	var cartas_no_monte = []
	for filho in get_children():
		if filho.has_method("virar"):
			cartas_no_monte.append(filho)
			
	if cartas_no_monte.size() > 0:
		var carta = cartas_no_monte.back() 
		remove_child(carta)
		descarte.add_child(carta)
		carta.virar(true)
		mesa.reorganizar_coluna(descarte)
		
	elif descarte.get_child_count() > 0:
		reciclar_monte(descarte)

func reciclar_monte(descarte):
	var cartas = descarte.get_children()
	for c in cartas:
		if c.has_method("virar"):
			descarte.remove_child(c)
			add_child(c)
			c.virar(false)
	
	var mesa = get_tree().current_scene
	mesa.reorganizar_coluna(self)
	mesa.reorganizar_coluna(descarte)
