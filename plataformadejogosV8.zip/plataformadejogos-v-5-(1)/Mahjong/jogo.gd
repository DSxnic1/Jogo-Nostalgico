extends Node2D

var pecaComp = preload("res://Mahjong/peca.tscn")

var categories = [
	"animais",
	"comida",
	"cultura",
	"folclore",
	"fruta",
	"objetos",
	"planta"
]

var max_numeros = {
	"animais": 9,
	"comida": 9,
	"cultura": 4,
	"folclore": 4,
	"fruta": 4,
	"objetos": 4,
	"planta": 9
}

var peca_selecionada: Node2D = null

var margem_esquerda: float = 0.0
var margem_topo: float = 0.0

var tile_w = 51
var tile_h = 66

var pecas_ativas: Array = []


func _ready():
	gerar_tabuleiro_automatico()

func calcular_margens(posicoes: Array):

	var min_c = INF
	var max_c = -INF
	var min_l = INF
	var max_l = -INF

	for p in posicoes:
		min_c = min(min_c, p.c)
		max_c = max(max_c, p.c)
		min_l = min(min_l, p.l)
		max_l = max(max_l, p.l)

	var largura = (max_c - min_c + 1) * tile_w
	var altura = (max_l - min_l + 1) * tile_h

	var tela = get_viewport().get_visible_rect().size

	margem_esquerda = (tela.x - largura) * 0.5 - min_c * tile_w
	margem_topo = (tela.y - altura) * 0.5 - min_l * tile_h

func gerar_tabuleiro_automatico():

	var posicoes: Array = []

	for c in range(2, 12):
		posicoes.append({"c": c, "l": 0, "n": 0})

	for c in range(1, 13):
		posicoes.append({"c": c, "l": 1, "n": 0})

	for extra in [-1, 0, 13, 14]:
		posicoes.append({"c": extra, "l": 1, "n": 0})

	for c in range(1, 13):
		posicoes.append({"c": c, "l": 2, "n": 0})

	for l in range(3, 8):
		for c in range(0, 14):
			posicoes.append({"c": c, "l": l, "n": 0})

	for l in [4, 5]:
		for c in [-2, -1, 14, 15]:
			posicoes.append({"c": c, "l": l, "n": 0})

	for c in range(1, 13):
		posicoes.append({"c": c, "l": 8, "n": 0})

	for extra in [-1, 0, 13, 14]:
		posicoes.append({"c": extra, "l": 8, "n": 0})

	for c in range(2, 12):
		posicoes.append({"c": c, "l": 9, "n": 0})

	# camadas
	for l in range(1, 9):
		for c in range(1, 13):
			posicoes.append({"c": c, "l": l, "n": 1})

	for l in range(2, 8):
		for c in range(2, 12):
			posicoes.append({"c": c, "l": l, "n": 2})

	for l in range(3, 7):
		for c in range(3, 11):
			posicoes.append({"c": c, "l": l, "n": 3})

	for l in range(4, 6):
		for c in range(4, 10):
			posicoes.append({"c": c, "l": l, "n": 4})

	if posicoes.size() % 2 != 0:
		posicoes.pop_back()

	calcular_margens(posicoes)

	var identidades = _gerar_identidades_em_pares(posicoes.size())
	posicoes.shuffle()

	for i in range(posicoes.size()):
		var pos = posicoes[i]
		var id = identidades[i]

		_instanciar_peca(pos.c, pos.l, pos.n, id.simbolo, id.numero)


func _sortear_identidade_valida() -> Dictionary:
	for i in range(100):
		var cat = categories.pick_random()
		var num = randi_range(1, max_numeros[cat])

		var caminho = "res://Mahjong/pecas/" + cat + " " + str(num) + ".png"

		if ResourceLoader.exists(caminho):
			return {"simbolo": cat, "numero": num}

	return {"simbolo": "animais", "numero": 1}


func _gerar_identidades_em_pares(total: int) -> Array:
	var lista = []

	for i in range(total / 2):
		var id = _sortear_identidade_valida()
		lista.append(id)
		lista.append(id.duplicate())

	lista.shuffle()
	return lista


func _instanciar_peca(c, l, n, sim, num):

	var peca = pecaComp.instantiate()
	
	# Força o script correto a carregar na instância criada
	peca.set_script(load("res://Mahjong/peca.gd"))

	peca.coluna = c
	peca.linha = l
	peca.nivel = n

	peca.simbolo = sim
	peca.numero = num

	add_child(peca)
	pecas_ativas.append(peca)


func processar_clique(peca):

	if esta_bloqueada(peca):
		return

	if peca_selecionada == null:
		peca_selecionada = peca
		peca.set_selecionada(true)
		return

	if peca_selecionada == peca:
		peca_selecionada.set_selecionada(false)
		peca_selecionada = null
		return

	if peca_selecionada.simbolo == peca.simbolo and peca_selecionada.numero == peca.numero:

		pecas_ativas.erase(peca_selecionada)
		pecas_ativas.erase(peca)

		peca_selecionada.queue_free()
		peca.queue_free()

		peca_selecionada = null
		verificar_vitoria()

	else:
		peca_selecionada.set_selecionada(false)
		peca_selecionada = peca
		peca.set_selecionada(true)


func verificar_vitoria():
	if pecas_ativas.is_empty():
		print("VOCÊ VENCEU!")


func esta_bloqueada(peca) -> bool:

	var cima = false
	var esquerda = false
	var direita = false

	for outra in pecas_ativas:

		if outra == peca:
			continue

		if outra.nivel > peca.nivel:
			if outra.coluna == peca.coluna and outra.linha == peca.linha:
				cima = true

		if outra.nivel == peca.nivel:
			if outra.linha == peca.linha:
				var d = outra.coluna - peca.coluna

				if d == -1:
					esquerda = true
				if d == 1:
					direita = true

	if cima:
		return true

	if esquerda and direita:
		return true

	return false
