extends Area2D
class_name Carta

enum Naipes {CAJU, GUARANA, PITANGA, MARACUJA}
@export var valor: int = 1
@export var naipe: Naipes = Naipes.CAJU
@export var virada_para_cima: bool = false

var arrastando: bool = false
var offset_mouse: Vector2 = Vector2.ZERO
var posicao_original: Vector2
var cartas_na_pilha: Array = []
var pai_original: Node2D = null

func _ready():
	posicao_original = global_position
	atualizar_visual()

func atualizar_visual():
	if not has_node("SpriteFrente") or not has_node("SpriteVerso"): return
	$SpriteFrente.visible = virada_para_cima
	$SpriteVerso.visible = !virada_para_cima
	if virada_para_cima:
		var nomes = ["caju", "guarana", "pitanga", "maracuja"]
		var s_valor = "A" if valor == 1 else str(valor)
		var path = "res://cartas/carta " + nomes[naipe] + " " + s_valor + ".png"
		if not ResourceLoader.exists(path): path = "res://cartas/carta " + nomes[naipe] + " " + str(valor) + ".png"
		if ResourceLoader.exists(path): $SpriteFrente.texture = load(path)
	else:
		if ResourceLoader.exists("res://cartas/fundo cartas.png"): $SpriteVerso.texture = load("res://cartas/fundo cartas.png")

func virar(cima: bool):
	virada_para_cima = cima
	atualizar_visual()

func eh_vermelha(): return int(naipe) == 0 or int(naipe) == 2

func pode_encaixar_em(coluna: Node2D) -> bool:
	if coluna.get_child_count() == 0: return true
	var ultima = coluna.get_child(coluna.get_child_count() - 1)
	return ultima.virada_para_cima and (ultima.valor == valor + 1) and (int(naipe)%2 != int(ultima.naipe)%2)

func pode_ir_para_destino(destino: Node2D) -> bool:
	if destino.get_child_count() == 0: return valor == 1
	var ultima = destino.get_child(destino.get_child_count() - 1)
	return (ultima.naipe == naipe) and (valor == ultima.valor + 1)

func _input_event(_v, event, _s):
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed and virada_para_cima:
		pai_original = get_parent()
		var cartas = pai_original.get_children()
		var idx = get_index()
		for i in range(idx, cartas.size()): if !cartas[i].virada_para_cima: return
		arrastando = true
		posicao_original = global_position
		offset_mouse = global_position - get_global_mouse_position()
		cartas_na_pilha = cartas.slice(idx + 1)
		self.z_index = 1000
		for c in cartas_na_pilha: c.z_index = 1000

func _input(event):
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and !event.pressed and arrastando:
		arrastando = false
		var mesa = get_tree().current_scene
		var alvos = mesa.obter_colunas() + [mesa.get_node("DestinoCaju"), mesa.get_node("DestinoGuarana"), mesa.get_node("DestinoMaracuja"), mesa.get_node("DestinoPitanga")]
		var melhor_alvo = null
		var dist_min = 120.0
		for a in alvos:
			var d = global_position.distance_to(a.global_position)
			if d < dist_min: dist_min = d; melhor_alvo = a
		
		if melhor_alvo and melhor_alvo != pai_original:
			var e_destino = "Destino" in melhor_alvo.name
			if (e_destino and pode_ir_para_destino(melhor_alvo)) or (!e_destino and pode_encaixar_em(melhor_alvo)):
				pai_original.remove_child(self)
				melhor_alvo.add_child(self)
				for c in cartas_na_pilha: 
					c.get_parent().remove_child(c)
					melhor_alvo.add_child(c)
				if pai_original.get_child_count() > 0: 
					pai_original.get_child(pai_original.get_child_count()-1).virar(true)
				mesa.reorganizar_coluna(pai_original)
				mesa.reorganizar_coluna(melhor_alvo)
			else: _cancelar_arrasto(mesa)
		else: _cancelar_arrasto(mesa)
		cartas_na_pilha.clear()

func _cancelar_arrasto(mesa):
	global_position = posicao_original
	mesa.reorganizar_coluna(pai_original)

func _process(_d):
	if arrastando:
		global_position = get_global_mouse_position() + offset_mouse
		for i in cartas_na_pilha.size(): 
			cartas_na_pilha[i].global_position = global_position + Vector2(0, (i+1)*35)
