extends Node2D

var cena_da_carta = preload("res://Carta.tscn")
var colunas: Array = []
var baralho: Array = []

@onready var monte_compra = $MonteCompra
@onready var monte_descarte = $MonteDescarte

func _ready():
	for i in range(1, 8):
		var col = get_node_or_null("Coluna" + str(i))
		if col: colunas.append(col)
	
	criar_baralho()
	distribuir_partida()

func criar_baralho():
	baralho.clear()
	for naipe_atual in range(4):
		for valor_atual in range(1, 11): 
			var nova_carta = cena_da_carta.instantiate()
			nova_carta.valor = valor_atual
			nova_carta.naipe = naipe_atual as Carta.Naipes
			nova_carta.virada_para_cima = false
			baralho.append(nova_carta)
	baralho.shuffle()

func distribuir_partida():
	# 1. Distribui nas colunas da mesa
	for i in range(7):
		for j in range(i + 1):
			if baralho.size() > 0:
				var carta = baralho.pop_back()
				colunas[i].add_child(carta)
				if j == i: carta.virar(true)
		reorganizar_coluna(colunas[i])
	
	# 2. O que sobrou vai para o MonteCompra
	for carta in baralho:
		carta.virada_para_cima = false
		carta.atualizar_visual()
		monte_compra.add_child(carta)
	
	reorganizar_coluna(monte_compra)

func obter_colunas(): 
	return colunas

func reorganizar_coluna(coluna_node: Node2D):
	# Destinos, Monte de Compra e Descarte: apenas empilha no centro
	if "Destino" in coluna_node.name or "Monte" in coluna_node.name:
		for c in coluna_node.get_children(): # <--- ESTA LINHA PRECISA DE UM TAB
			c.position = Vector2.ZERO        # <--- ESTA TAMBÉM
			c.z_index = c.get_index()        # <--- ESTA TAMBÉM
		return                               # <--- ESTA TAMBÉM
		
	# Cascata das colunas da mesa
	var offset_y = 0.0
	for c in coluna_node.get_children():
		c.position = Vector2(0, offset_y)
		c.z_index = c.get_index()
		offset_y += 35.0 if c.virada_para_cima else 18.0

func _on_button_pressed():
	get_tree().change_scene_to_file("res://Telainicial.tscn")
