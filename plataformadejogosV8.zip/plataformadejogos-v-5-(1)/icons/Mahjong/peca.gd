extends Node2D

var coluna: int
var linha: int
var nivel: int

var numero: int
var simbolo: String

var selecionada = false
var mouse_em_cima = false

var largura_peca = 51
var altura_peca = 66

var deslocamento_x = -4
var deslocamento_y = -5

@onready var visual = $VisualPeca


func _ready():

	add_to_group("pecas_tabuleiro")

	var caminho = "res://pecas/" + simbolo + " " + str(numero) + ".png"

	if ResourceLoader.exists(caminho):
		visual.texture = load(caminho)

		var s = visual.texture.get_size()
		visual.scale = Vector2(
			largura_peca / s.x,
			altura_peca / s.y
		)

		visual.centered = false

	var jogo = get_parent()

	position.x = jogo.margem_esquerda + coluna * largura_peca + nivel * deslocamento_x
	position.y = jogo.margem_topo + linha * altura_peca + nivel * deslocamento_y

	z_index = nivel * 100 + linha

	atualizar_cor()


func set_selecionada(v: bool):
	selecionada = v
	atualizar_cor()


func atualizar_cor():

	if selecionada:
		modulate = Color(1.6, 1.6, 0.6)
	elif mouse_em_cima:
		modulate = Color(1.3, 1.3, 1.3)
	else:
		var t = 0.75 + nivel * 0.06
		modulate = Color(t, t, t)


func _input(event):

	if event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_LEFT:

			var area = Rect2(
				global_position,
				Vector2(largura_peca, altura_peca)
			)

			if area.has_point(get_global_mouse_position()):
				get_parent().processar_clique(self)


func _process(delta):

	var area = Rect2(global_position, Vector2(largura_peca, altura_peca))
	var dentro = area.has_point(get_global_mouse_position())

	if dentro != mouse_em_cima:
		mouse_em_cima = dentro
		atualizar_cor()
