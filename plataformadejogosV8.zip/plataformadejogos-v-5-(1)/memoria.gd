extends Control

# Arraste o seu GridContainer e seu Timer da cena Memoria para cá segurando Ctrl
@onready var grid_container = $GridContainer
@onready var timer_desvirar = $Timer

# Carrega a nossa NOVA cena de carta específica para a memória
var cena_carta_memoria = preload("res://CartaMemoria.tscn")

# Coloque aqui dentro do array as imagens que você quer usar como pares (ex: churrasco, chimarrão...)
@export var imagens_pares : Array[Texture2D] = []

var primeira_carta = null
var segunda_carta = null
var pode_clicar : bool = true

func _ready() -> void:
	timer_desvirar.timeout.connect(_on_timer_desvirar_timeout)
	inicializar_tabuleiro()

func _gerar_lista_embaralhada() -> Array:
	var lista = []
	for i in range(imagens_pares.size()):
		lista.append(i)
		lista.append(i) # Adiciona duas vezes para criar o par
	lista.shuffle()
	return lista

func inicializar_tabuleiro() -> void:
	var ids_embaralhados = _gerar_lista_embaralhada()
	
	# Limpa o grid por segurança
	for child in grid_container.get_children():
		child.queue_free()
		
	# Instancia as cartas novas
	for id in ids_embaralhados:
		var nova_carta = cena_carta_memoria.instantiate()
		grid_container.add_child(nova_carta)
		
		nova_carta.configurar_carta(id, imagens_pares[id])
		nova_carta.carta_clicada.connect(_on_carta_clicada)

func _on_carta_clicada(carta) -> void:
	if not pode_clicar:
		return
		
	carta.virar(true)
	
	if primeira_carta == null:
		primeira_carta = carta
	else:
		segunda_carta = carta
		pode_clicar = false
		verificar_par()

func verificar_par() -> void:
	if primeira_carta.id_par == segunda_carta.id_par:
		primeira_carta.resolvida = true  # <- minúsculo aqui
		segunda_carta.resolvida = true   # <- e minúsculo aqui
		limpar_selecao()
		# Aqui você pode checar se ganhou o jogo depois!
	else:
		timer_desvirar.start() # Espera 1 segundo antes de desvirar

func _on_timer_desvirar_timeout() -> void:
	primeira_carta.virar(false)
	segunda_carta.virar(false)
	limpar_selecao()

func limpar_selecao() -> void:
	primeira_carta = null
	segunda_carta = null
	pode_clicar = true


func _on_sair_pressed() -> void:
	get_tree().change_scene_to_file("res://Telainicial.tscn")
