extends TextureButton

# Sinal que avisa a tela principal qual carta foi clicada
signal carta_clicada(nodo_carta)

var id_par : int = 0
var resolvida : bool = false
var face_para_cima : bool = false

# Arraste a imagem do verso das suas cartas para cá no Inspetor (ou mude o caminho)
var textura_verso = preload("res://cartas/fundo cartas.png") 
var textura_frente : Texture2D

func configurar_carta(id: int, imagem_frente: Texture2D) -> void:
	id_par = id
	textura_frente = imagem_frente
	texture_normal = textura_verso # Começa virada para baixo
	resolvida = false
	face_para_cima = false

func virar(mostrar: bool) -> void:
	if resolvida:
		return
	face_para_cima = mostrar
	texture_normal = textura_frente if mostrar else textura_verso

func _pressed() -> void:
	# Só avisa o jogo se a carta não estiver resolvida e não estiver virada para cima
	if not face_para_cima and not resolvida:
		emit_signal("carta_clicada", self)
