extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_caça_palavras_pressed() -> void:
	# Altera para a cena do Caça-Palavras
	get_tree().change_scene_to_file("res://CaçaPalavras.tscn")


func _on_majong_pressed() -> void:
	# Altera para a cena do Mahjong
	get_tree().change_scene_to_file("res://Mahjong/jogo.tscn")


func _on_paciencia_pressed() -> void:
	# Altera para a cena do Paciência
	get_tree().change_scene_to_file("res://Mesa.tscn")


func _on_tetris_pressed() -> void:
	get_tree().change_scene_to_file("res://Tetris.tscn")


func _on_pong_pressed() -> void:
	get_tree().change_scene_to_file("res://Pong.tscn")


func _on_paciencia_spider_pressed() -> void:
	get_tree().change_scene_to_file("res://PacienciaSpider.tscn")


func _on_damas_pressed() -> void:
	get_tree().change_scene_to_file("res://Damas.tscn")


func _on_memoria_pressed() -> void:
	get_tree().change_scene_to_file("res://Memoria.tscn")


func _on_xadrez_pressed() -> void:
	get_tree().change_scene_to_file("res://Xadrez.tscn")


func _on_palavras_cruzadas_pressed() -> void:
	get_tree().change_scene_to_file("res://PalavrasCruzadas.tscn")


func _on_botao_sair_pressed() -> void:
	print("Botão foi clicado!")
	get_tree().quit()
