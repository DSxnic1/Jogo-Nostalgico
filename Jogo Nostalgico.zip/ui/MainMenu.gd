extends Control

func _ready():
    $CenterContainer/VBoxContainer/BtnCartas.pressed.connect(_on_cards)
    $CenterContainer/VBoxContainer/BtnArcade.pressed.connect(_on_arcade)

func _on_cards():
    GameManager.load_game("res://games/cards/CardGame.tscn")

func _on_arcade():
    GameManager.load_game("res://games/arcade/ArcadeGame.tscn")
