extends Node2D

var deck = []

func _ready():
    create_deck()
    shuffle_deck()
    draw_card()

func create_deck():
    var suits = ["♠","♥","♦","♣"]
    for s in suits:
        for v in range(1,14):
            deck.append({"suit": s, "value": v})

func shuffle_deck():
    deck.shuffle()

func draw_card():
    if deck.size() > 0:
        print(deck.pop_back())

func _input(event):
    if event.is_action_pressed("ui_cancel"):
        GameManager.load_game("res://ui/MainMenu.tscn")
