extends Node2D

func _input(event):
    if event.is_action_pressed("ui_cancel"):
        GameManager.load_game("res://ui/MainMenu.tscn")
