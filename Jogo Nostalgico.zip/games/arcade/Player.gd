extends CharacterBody2D

var speed = 250

func _physics_process(delta):
    var dir = Vector2.ZERO
    dir.x = Input.get_action_strength("ui_right") - Input.get_action_strength("ui_left")
    dir.y = Input.get_action_strength("ui_down") - Input.get_action_strength("ui_up")
    velocity = dir.normalized() * speed
    move_and_slide()
