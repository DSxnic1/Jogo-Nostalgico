extends Node

var current_game: Node = null

func load_game(scene_path: String):
    if current_game:
        current_game.queue_free()

    var scene = load(scene_path).instantiate()
    get_tree().root.add_child(scene)
    current_game = scene
