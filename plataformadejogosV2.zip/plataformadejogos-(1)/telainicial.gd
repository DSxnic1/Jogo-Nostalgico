extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_caça_palavras_pressed() -> void:
	# Altera para a cena do Caça-Palavras
	get_tree().change_scene_to_file("res://CaçaPalavras.tscn")


func _on_majong_pressed() -> void:
	# Altera para a cena do Mahjong
	get_tree().change_scene_to_file("res://Mahjong.tscn")


func _on_paciencia_pressed() -> void:
	# Altera para a cena do Paciência
	get_tree().change_scene_to_file("res://Paciencia.tscn")
